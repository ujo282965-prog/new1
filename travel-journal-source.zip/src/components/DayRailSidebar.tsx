import { Download, FileArchive, Loader2, Plus, Upload } from "lucide-react";
import { useRef } from "react";
import type { Trip } from "../types/travel";

interface DayRailSidebarProps {
  trip: Trip;
  selectedDay: number | "all";
  onSelectDay: (day: number | "all") => void;
  onAddDay: () => void;
  onExportTrip: () => void;
  onImportTrips: (file: File) => void;
  onOpenAppendix: () => void;
  onDownloadSource: () => void;
  isDownloadingSource: boolean;
  importNotice: string | null;
}

export function DayRailSidebar({
  trip,
  selectedDay,
  onSelectDay,
  onAddDay,
  onExportTrip,
  onImportTrips,
  onOpenAppendix,
  onDownloadSource,
  isDownloadingSource,
  importNotice,
}: DayRailSidebarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const allItems = trip.days.flatMap((d) => d.items);
  const categoryCounts = allItems.reduce<Record<string, number>>((acc, item) => {
    acc[item.category] = (acc[item.category] ?? 0) + 1;
    return acc;
  }, {});
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  const packedDone = (trip.packingList ?? []).filter((p) => p.checked).length;
  const packedTotal = (trip.packingList ?? []).length;

  return (
    <aside className="lg:w-[270px] shrink-0 space-y-6 lg:sticky lg:top-22">
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD3]">
          <h2 className="text-xs font-semibold tracking-wider text-[#6B655E]">
            여정 목차
          </h2>
          <button
            type="button"
            onClick={onAddDay}
            className="inline-flex items-center gap-1 text-xs font-medium text-[#1B4332] hover:underline cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>일차 추가</span>
          </button>
        </div>

        <ul className="mt-3 space-y-1">
          <li>
            <button
              type="button"
              onClick={() => onSelectDay("all")}
              className={`w-full text-left px-3 py-2.5 rounded-md transition-colors cursor-pointer flex items-center justify-between ${
                selectedDay === "all"
                  ? "bg-[#F3EFE6] text-[#1C1917] font-medium border border-[#E5DFD3]"
                  : "text-[#6B655E] hover:text-[#1C1917] hover:bg-[#F3EFE6]/60 border border-transparent"
              }`}
            >
              <span className="text-sm">전체 일자 한눈에</span>
              <span className="font-mono-tabular text-xs text-[#6B655E]">
                {trip.days.length}일
              </span>
            </button>
          </li>

          {trip.days.map((day) => {
            const active = selectedDay === day.dayNumber;
            const formattedNum = String(day.dayNumber).padStart(2, "0");
            return (
              <li key={day.dayNumber}>
                <button
                  type="button"
                  onClick={() => onSelectDay(day.dayNumber)}
                  className={`w-full text-left px-3 py-2.5 rounded-md transition-colors cursor-pointer ${
                    active
                      ? "bg-[#F3EFE6] text-[#1C1917] border border-[#E5DFD3]"
                      : "text-[#4A453F] hover:text-[#1C1917] hover:bg-[#F3EFE6]/60 border border-transparent"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono-tabular text-xs font-medium text-[#1B4332]">
                      Day {formattedNum}
                    </span>
                    <span className="font-mono-tabular text-xs text-[#6B655E]">
                      {day.items.length}곳
                    </span>
                  </div>
                  <p className="mt-0.5 text-sm font-medium truncate text-[#1C1917]">
                    {day.title || `${day.dayNumber}일차 여정`}
                  </p>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Category Balance & Quick Appendix Summary */}
      <div className="pt-5 border-t border-[#E5DFD3] space-y-3">
        <p className="text-xs font-semibold tracking-wider text-[#6B655E]">
          테마 구성 & 부록 요약
        </p>

        {topCategories.length > 0 && (
          <div className="space-y-2">
            {topCategories.map(([cat, count]) => {
              const pct = Math.round((count / Math.max(1, allItems.length)) * 100);
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#4A453F]">{cat}</span>
                    <span className="font-mono-tabular text-[#6B655E]">
                      {count}곳 ({pct}%)
                    </span>
                  </div>
                  <div className="h-1 bg-[#E5DFD3] overflow-hidden">
                    <div
                      className="h-full bg-[#1B4332]"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <button
          type="button"
          onClick={onOpenAppendix}
          className="w-full text-left bg-[#F3EFE6] border border-[#E5DFD3] p-3 hover:border-[#1B4332]/50 transition-colors cursor-pointer space-y-1"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-[#1C1917]">예약 · 경비 · 준비물</span>
            <span className="font-mono-tabular text-[#1B4332]">열기 →</span>
          </div>
          <p className="font-mono-tabular text-[11px] text-[#6B655E]">
            동행 {(trip.travelers ?? ["나"]).length}명 · 예약 {(trip.reservations ?? []).length}건 · 준비물{" "}
            {packedDone}/{packedTotal}
          </p>
        </button>
      </div>

      <div className="pt-5 border-t border-[#E5DFD3] space-y-2.5">
        <p className="text-xs font-semibold tracking-wider text-[#6B655E]">
          로컬 백업 및 공유
        </p>
        <p className="text-xs leading-relaxed text-[#6B655E]">
          모든 변경 사항은 이 브라우저에 자동 저장됩니다. 동행자에게 전달하려면 파일로 내보내세요.
        </p>
        <div className="flex flex-col gap-2 pt-1">
          <button
            type="button"
            onClick={onExportTrip}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1C1917] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>현재 여행 JSON 내보내기</span>
          </button>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-[#4A453F] bg-transparent border border-[#E5DFD3] rounded-md hover:bg-[#F3EFE6] transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" aria-hidden="true" />
            <span>JSON 파일 불러오기</span>
          </button>
          <button
            type="button"
            disabled={isDownloadingSource}
            onClick={onDownloadSource}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1B4332] bg-[#F3EFE6] border border-[#1B4332]/30 rounded-md hover:bg-[#1B4332]/10 disabled:opacity-60 transition-colors cursor-pointer"
          >
            {isDownloadingSource ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                <span>소스코드 압축 중...</span>
              </>
            ) : (
              <>
                <FileArchive className="w-3.5 h-3.5" aria-hidden="true" />
                <span>앱 소스코드 다운로드 (.zip)</span>
              </>
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onImportTrips(file);
                e.target.value = "";
              }
            }}
          />
        </div>
        {importNotice && (
          <p className="text-xs text-[#1B4332] pt-1" role="status">
            {importNotice}
          </p>
        )}
      </div>
    </aside>
  );
}
