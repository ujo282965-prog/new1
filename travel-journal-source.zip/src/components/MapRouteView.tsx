import {
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useMap,
  useMapsLibrary,
} from "@vis.gl/react-google-maps";
import {
  ArrowLeft,
  Car,
  Footprints,
  Loader2,
  MapPin,
  RefreshCw,
  TrainFront,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { ItineraryItem, LatLngLiteral, Trip } from "../types/travel";

interface MapRouteViewProps {
  trip: Trip;
  mapsApiKey: string;
  initialDayNumber: number;
  onUpdateItemLocation: (
    dayNumber: number,
    itemId: string,
    patch: {
      placeId?: string;
      formattedAddress?: string;
      location?: LatLngLiteral;
    }
  ) => void;
  onBackToEditor: () => void;
}

type TravelModeOption = "WALK" | "TRANSIT" | "DRIVE";

interface LegSummary {
  distanceMeters: number;
  durationMillis: number;
}

function formatDistance(meters: number): string {
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

function formatDuration(millis: number): string {
  const mins = Math.max(1, Math.round(millis / 60000));
  if (mins < 60) return `약 ${mins}분`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `약 ${h}시간 ${m}분` : `약 ${h}시간`;
}

function StopMarker({
  index,
  item,
  isSelected,
  onSelect,
  onClose,
}: {
  index: number;
  item: ItineraryItem;
  isSelected: boolean;
  onSelect: () => void;
  onClose: () => void;
}) {
  const [markerRef, setMarkerRef] =
    useState<google.maps.marker.AdvancedMarkerElement | null>(null);

  if (!item.location) return null;

  return (
    <>
      <AdvancedMarker
        ref={setMarkerRef}
        position={item.location}
        title={`${index + 1}. ${item.title}`}
        onClick={onSelect}
      >
        <Pin
          background={isSelected ? "#8C4A27" : "#1B4332"}
          borderColor="#FBF9F5"
          glyphColor="#FBF9F5"
          glyphText={String(index + 1)}
          scale={isSelected ? 1.2 : 1.05}
        />
      </AdvancedMarker>

      {isSelected && markerRef && (
        <InfoWindow anchor={markerRef} onCloseClick={onClose} maxWidth={260}>
          <div className="p-1 space-y-1 text-[#1C1917]">
            <p className="font-mono-tabular text-[11px] font-medium text-[#1B4332]">
              #{index + 1} · {item.time} · {item.category}
            </p>
            <p className="text-sm font-semibold leading-snug">{item.title}</p>
            {item.formattedAddress && (
              <p className="text-xs text-[#6B655E] leading-snug">
                {item.formattedAddress}
              </p>
            )}
            {item.note && (
              <p className="text-xs text-[#4A453F] leading-snug pt-0.5">
                {item.note}
              </p>
            )}
          </div>
        </InfoWindow>
      )}
    </>
  );
}

function RouteAndBoundsController({
  resolvedItems,
  travelMode,
  onRouteComputed,
  onRouteError,
}: {
  resolvedItems: ItineraryItem[];
  travelMode: TravelModeOption;
  onRouteComputed: (summary: {
    totalDistanceMeters: number;
    totalDurationMillis: number;
    legs: LegSummary[];
  } | null) => void;
  onRouteError: (msg: string | null) => void;
}) {
  const map = useMap();
  const routesLib = useMapsLibrary("routes");

  // Fit bounds whenever resolved coordinates change
  useEffect(() => {
    if (!map || resolvedItems.length === 0) return;
    if (resolvedItems.length === 1 && resolvedItems[0].location) {
      map.panTo(resolvedItems[0].location);
      map.setZoom(14);
      return;
    }
    const bounds = new google.maps.LatLngBounds();
    resolvedItems.forEach((item) => {
      if (item.location) bounds.extend(item.location);
    });
    map.fitBounds(bounds, 64);
  }, [map, resolvedItems]);

  // Compute Routes API polyline between ordered stops
  useEffect(() => {
    if (!map || !routesLib) return;
    const validStops = resolvedItems.filter((i) => Boolean(i.location));
    if (validStops.length < 2) {
      onRouteComputed(null);
      onRouteError(null);
      return;
    }

    let cancelled = false;
    const activePolylines: google.maps.Polyline[] = [];

    const run = async () => {
      try {
        onRouteError(null);
        const origin = validStops[0].location!;
        const destination = validStops[validStops.length - 1].location!;
        const intermediates = validStops.slice(1, -1).map((stop) => ({
          location: stop.location!,
        }));

        const modeMap: Record<TravelModeOption, google.maps.TravelModeString> = {
          WALK: "WALKING",
          TRANSIT: "TRANSIT",
          DRIVE: "DRIVING",
        };

        // TRANSIT does not support multiple intermediate waypoints in Routes API;
        // compute leg-by-leg if TRANSIT with >2 stops, or single computeRoutes for WALK/DRIVE.
        if (travelMode === "TRANSIT" && intermediates.length > 0) {
          let totalDist = 0;
          let totalDur = 0;
          const legs: LegSummary[] = [];

          for (let i = 0; i < validStops.length - 1; i++) {
            const resp = await routesLib.Route.computeRoutes({
              origin: validStops[i].location!,
              destination: validStops[i + 1].location!,
              travelMode: "TRANSIT",
              fields: ["distanceMeters", "durationMillis", "path"],
              language: "ko",
            });
            if (cancelled) return;
            const r = resp.routes?.[0];
            if (r) {
              totalDist += r.distanceMeters ?? 0;
              totalDur += r.durationMillis ?? 0;
              legs.push({
                distanceMeters: r.distanceMeters ?? 0,
                durationMillis: r.durationMillis ?? 0,
              });
              if (r.path && r.path.length > 0) {
                const line = new google.maps.Polyline({
                  path: r.path.map((p) => ({ lat: p.lat, lng: p.lng })),
                  geodesic: true,
                  strokeColor: "#1B4332",
                  strokeOpacity: 0.88,
                  strokeWeight: 4,
                  map,
                });
                activePolylines.push(line);
              }
            }
          }
          if (!cancelled) {
            onRouteComputed({
              totalDistanceMeters: totalDist,
              totalDurationMillis: totalDur,
              legs,
            });
          }
          return;
        }

        const resp = await routesLib.Route.computeRoutes({
          origin,
          destination,
          intermediates: intermediates.length > 0 ? intermediates : undefined,
          travelMode: modeMap[travelMode],
          fields: ["distanceMeters", "durationMillis", "path", "legs"],
          language: "ko",
        });

        if (cancelled) return;
        const primary = resp.routes?.[0];
        if (!primary) {
          onRouteComputed(null);
          onRouteError("선택한 이동 수단으로 연결 경로를 찾지 못했습니다.");
          return;
        }

        if (primary.path && primary.path.length > 0) {
          const line = new google.maps.Polyline({
            path: primary.path.map((p) => ({ lat: p.lat, lng: p.lng })),
            geodesic: true,
            strokeColor: "#1B4332",
            strokeOpacity: 0.9,
            strokeWeight: 4,
            map,
          });
          activePolylines.push(line);
        }

        const legList: LegSummary[] = (primary.legs ?? []).map((leg) => ({
          distanceMeters: leg.distanceMeters ?? 0,
          durationMillis: leg.durationMillis ?? 0,
        }));

        onRouteComputed({
          totalDistanceMeters: primary.distanceMeters ?? 0,
          totalDurationMillis: primary.durationMillis ?? 0,
          legs: legList,
        });
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes("RESOURCE_EXHAUSTED") || msg.includes("OVER_QUERY_LIMIT")) {
          window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
        }
        onRouteComputed(null);
        onRouteError("일부 구간은 선택한 이동 수단 경로를 산출할 수 없습니다.");
      }
    };

    run();

    return () => {
      cancelled = true;
      activePolylines.forEach((p) => p.setMap(null));
    };
  }, [map, routesLib, resolvedItems, travelMode, onRouteComputed, onRouteError]);

  return null;
}

export function MapRouteView({
  trip,
  mapsApiKey,
  initialDayNumber,
  onUpdateItemLocation,
  onBackToEditor,
}: MapRouteViewProps) {
  const placesLib = useMapsLibrary("places");
  const [selectedDayNum, setSelectedDayNum] = useState(initialDayNumber);
  const [travelMode, setTravelMode] = useState<TravelModeOption>("WALK");
  const [selectedStopId, setSelectedStopId] = useState<string | null>(null);
  const [isResolving, setIsResolving] = useState(false);
  const [resolveFailedIds, setResolveFailedIds] = useState<Record<string, boolean>>({});
  const [routeSummary, setRouteSummary] = useState<{
    totalDistanceMeters: number;
    totalDurationMillis: number;
    legs: LegSummary[];
  } | null>(null);
  const [routeError, setRouteError] = useState<string | null>(null);

  const activeDay = useMemo(
    () =>
      trip.days.find((d) => d.dayNumber === selectedDayNum) ?? trip.days[0],
    [trip.days, selectedDayNum]
  );

  const resolveMissingLocations = useCallback(
    async (forceAll = false) => {
      if (!placesLib || !activeDay) return;
      const targets = activeDay.items.filter(
        (item) => forceAll || (!item.location && !resolveFailedIds[item.id])
      );
      if (targets.length === 0) return;

      setIsResolving(true);
      const nextFailed: Record<string, boolean> = forceAll ? {} : { ...resolveFailedIds };

      for (const item of targets) {
        try {
          const query = `${item.title} ${item.area || ""} ${trip.destination}`.trim();
          const { places } = await placesLib.Place.searchByText({
            textQuery: query,
            fields: ["id", "displayName", "formattedAddress", "location"],
            maxResultCount: 1,
            language: "ko",
          });
          const match = places?.[0];
          if (match?.location) {
            onUpdateItemLocation(activeDay.dayNumber, item.id, {
              placeId: match.id,
              formattedAddress: match.formattedAddress ?? undefined,
              location: {
                lat: match.location.lat(),
                lng: match.location.lng(),
              },
            });
            delete nextFailed[item.id];
          } else {
            nextFailed[item.id] = true;
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          if (msg.includes("RESOURCE_EXHAUSTED") || msg.includes("OVER_QUERY_LIMIT")) {
            window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
            break;
          }
          nextFailed[item.id] = true;
        }
      }

      setResolveFailedIds(nextFailed);
      setIsResolving(false);
    },
    [placesLib, activeDay, trip.destination, resolveFailedIds, onUpdateItemLocation]
  );

  useEffect(() => {
    resolveMissingLocations(false);
  }, [resolveMissingLocations]);

  const resolvedItems = useMemo(
    () => (activeDay?.items ?? []).filter((i) => Boolean(i.location)),
    [activeDay]
  );

  const handleRouteComputed = useCallback(
    (
      summary: {
        totalDistanceMeters: number;
        totalDurationMillis: number;
        legs: LegSummary[];
      } | null
    ) => {
      setRouteSummary(summary);
    },
    []
  );

  const handleRouteError = useCallback((msg: string | null) => {
    setRouteError(msg);
  }, []);

  if (!mapsApiKey) {
    return (
      <main className="max-w-[1200px] mx-auto px-6 lg:px-10 py-12">
        <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-8 text-center space-y-3">
          <h1 className="font-editorial text-2xl font-semibold text-[#1C1917]">
            지도 API 키를 불러오는 중입니다
          </h1>
          <p className="text-sm text-[#6B655E]">
            Google Maps API 키가 환경에 설정되어 있는지 확인한 뒤 다시 열어주세요.
          </p>
          <button
            type="button"
            onClick={onBackToEditor}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            <span>일정 편집으로 돌아가기</span>
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#E5DFD3]">
        <div>
          <p className="font-mono-tabular text-xs text-[#1B4332]">
            ROUTE & SPATIAL VIEW · {trip.destination}
          </p>
          <h1 className="mt-1 font-editorial text-3xl font-semibold text-[#1C1917]">
            일자별 지도 동선 보기
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex border border-[#D4CBB8] bg-[#FFFFFF] rounded-md p-0.5">
            {(
              [
                { id: "WALK", label: "도보", icon: Footprints },
                { id: "TRANSIT", label: "대중교통", icon: TrainFront },
                { id: "DRIVE", label: "차량", icon: Car },
              ] as const
            ).map((mode) => {
              const Icon = mode.icon;
              return (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setTravelMode(mode.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
                    travelMode === mode.id
                      ? "bg-[#1B4332] text-[#FBF9F5]"
                      : "text-[#4A453F] hover:text-[#1C1917]"
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{mode.label}</span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => resolveMissingLocations(true)}
            disabled={isResolving}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1C1917] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] cursor-pointer whitespace-nowrap"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isResolving ? "animate-spin" : ""}`}
              aria-hidden="true"
            />
            <span>위치 재탐색</span>
          </button>
        </div>
      </div>

      {/* Day Tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {trip.days.map((d) => (
          <button
            key={d.dayNumber}
            type="button"
            onClick={() => {
              setSelectedDayNum(d.dayNumber);
              setSelectedStopId(null);
            }}
            className={`px-3.5 py-2 text-xs font-medium rounded-md border transition-colors cursor-pointer whitespace-nowrap ${
              activeDay?.dayNumber === d.dayNumber
                ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8] hover:border-[#1C1917]"
            }`}
          >
            Day {String(d.dayNumber).padStart(2, "0")} · {d.items.length}곳
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Chronological Stop Sequence */}
        <div className="lg:col-span-4 bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-4">
          <div className="pb-3 border-b border-[#E5DFD3]">
            <p className="font-mono-tabular text-xs text-[#1B4332]">
              Day {String(activeDay?.dayNumber ?? 1).padStart(2, "0")}
            </p>
            <h2 className="mt-0.5 font-editorial text-lg font-semibold text-[#1C1917]">
              {activeDay?.title}
            </h2>
            {routeSummary && (
              <p className="mt-1.5 font-mono-tabular text-xs text-[#4A453F]">
                총 이동 {formatDistance(routeSummary.totalDistanceMeters)} ·{" "}
                {formatDuration(routeSummary.totalDurationMillis)}
              </p>
            )}
            {routeError && (
              <p className="mt-1.5 text-xs text-[#8C4A27]">{routeError}</p>
            )}
          </div>

          {isResolving && (
            <div className="flex items-center gap-2 text-xs text-[#1B4332]">
              <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
              <span>Google 지도에서 장소 좌표를 확인하는 중...</span>
            </div>
          )}

          <div className="divide-y divide-[#E5DFD3]">
            {(activeDay?.items ?? []).map((item, idx) => {
              const hasCoord = Boolean(item.location);
              const isSelected = selectedStopId === item.id;
              const leg = routeSummary?.legs[idx];
              return (
                <div key={item.id} className="py-3">
                  <button
                    type="button"
                    onClick={() => setSelectedStopId(item.id)}
                    className={`w-full text-left p-2 -mx-2 rounded transition-colors cursor-pointer flex items-start gap-3 ${
                      isSelected ? "bg-[#FFFFFF]" : "hover:bg-[#FFFFFF]/60"
                    }`}
                  >
                    <span
                      className={`w-6 h-6 rounded-full font-mono-tabular text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5 ${
                        hasCoord
                          ? "bg-[#1B4332] text-[#FBF9F5]"
                          : "bg-[#D4CBB8] text-[#4A453F]"
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-mono-tabular text-xs text-[#6B655E]">
                        {item.time} · {item.category}
                      </p>
                      <p className="text-sm font-semibold text-[#1C1917] truncate">
                        {item.title}
                      </p>
                      <p className="text-xs text-[#6B655E] truncate">
                        {item.formattedAddress ||
                          (hasCoord
                            ? item.area
                            : "위치 미확인 — 일정 편집에서 장소 검색으로 연결하세요")}
                      </p>
                    </div>
                    {hasCoord && (
                      <MapPin className="w-3.5 h-3.5 text-[#1B4332] shrink-0 mt-1" aria-hidden="true" />
                    )}
                  </button>

                  {leg && idx < (activeDay?.items.length ?? 0) - 1 && (
                    <p className="mt-1.5 pl-9 font-mono-tabular text-[11px] text-[#8C4A27]">
                      ↓ 다음 장소까지 {formatDistance(leg.distanceMeters)} (
                      {formatDuration(leg.durationMillis)})
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Interactive Google Map */}
        <div className="lg:col-span-8 border border-[#E5DFD3] bg-[#F3EFE6] h-[540px] lg:h-[calc(100vh-260px)] min-h-[540px] w-full relative">
          <GoogleMap
            mapId="DEMO_MAP_ID"
            defaultCenter={{ lat: 35.0116, lng: 135.7681 }}
            defaultZoom={12}
            gestureHandling="greedy"
            disableDefaultUI={false}
            internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
            className="w-full h-full"
          >
            {resolvedItems.map((item, idx) => (
              <StopMarker
                key={item.id}
                index={idx}
                item={item}
                isSelected={selectedStopId === item.id}
                onSelect={() => setSelectedStopId(item.id)}
                onClose={() => setSelectedStopId(null)}
              />
            ))}

            <RouteAndBoundsController
              resolvedItems={resolvedItems}
              travelMode={travelMode}
              onRouteComputed={handleRouteComputed}
              onRouteError={handleRouteError}
            />
          </GoogleMap>
        </div>
      </div>
    </main>
  );
}
