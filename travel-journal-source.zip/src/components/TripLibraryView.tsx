import { Copy, FolderOpen, Plus, RotateCcw, Sparkles, Trash2 } from "lucide-react";
import { useState } from "react";
import type { Trip } from "../types/travel";
import { calculateNightsAndDays, formatDateRange } from "../utils/storage";
import { CoverImage } from "./CoverImage";

interface TripLibraryViewProps {
  trips: Trip[];
  activeTripId: string;
  onSelectTrip: (tripId: string) => void;
  onDuplicateTrip: (tripId: string) => void;
  onDeleteTrip: (tripId: string) => void;
  onRestoreSeeds: () => void;
  onOpenNewTrip: () => void;
  onOpenAIPlanner: () => void;
}

export function TripLibraryView({
  trips,
  activeTripId,
  onSelectTrip,
  onDuplicateTrip,
  onDeleteTrip,
  onRestoreSeeds,
  onOpenNewTrip,
  onOpenAIPlanner,
}: TripLibraryViewProps) {
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  return (
    <main className="max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-[#E5DFD3]">
        <div>
          <p className="font-mono-tabular text-xs text-[#1B4332]">
            PERSONAL ARCHIVE · {trips.length} VOLUMES
          </p>
          <h1 className="mt-1 font-editorial text-3xl font-semibold text-[#1C1917]">
            내 여행 저널 서가
          </h1>
          <p className="mt-1.5 text-sm text-[#6B655E]">
            브라우저에 보관된 모든 여행 일정을 한곳에서 전환·복제·정리할 수 있습니다.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onRestoreSeeds}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#4A453F] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>샘플 저널 불러오기</span>
          </button>
          <button
            type="button"
            onClick={onOpenAIPlanner}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1B4332] border border-[#1B4332]/40 rounded-md hover:bg-[#1B4332]/5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
            <span>AI 코스 추천</span>
          </button>
          <button
            type="button"
            onClick={onOpenNewTrip}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>새 여행 만들기</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {trips.map((trip) => {
          const isActive = trip.id === activeTripId;
          const totalItems = trip.days.reduce((s, d) => s + d.items.length, 0);
          const isConfirming = confirmDeleteId === trip.id;

          return (
            <article
              key={trip.id}
              className={`border bg-[#FFFFFF] flex flex-col justify-between transition-colors ${
                isActive ? "border-[#1B4332]" : "border-[#E5DFD3]"
              }`}
            >
              <div>
                <div className="aspect-[16/10] overflow-hidden border-b border-[#E5DFD3] bg-[#F3EFE6]">
                  <CoverImage
                    src={trip.coverImage}
                    alt={trip.title}
                    className="w-full h-full"
                  />
                </div>

                <div className="p-5 space-y-2.5">
                  <div className="flex items-center justify-between gap-2 text-xs text-[#6B655E]">
                    <span className="font-medium text-[#1B4332]">{trip.destination}</span>
                    <span className="font-mono-tabular">
                      {calculateNightsAndDays(trip.startDate, trip.endDate, trip.days.length)}
                    </span>
                  </div>

                  <h2 className="font-editorial text-xl font-semibold text-[#1C1917] leading-snug text-balance">
                    {trip.title}
                  </h2>

                  <p className="text-xs text-[#6B655E] tabular-nums">
                    {formatDateRange(trip.startDate, trip.endDate)} · {trip.companions} ·{" "}
                    {totalItems}개 일정
                  </p>

                  {trip.journalNote && (
                    <p className="text-xs text-[#4A453F] leading-relaxed line-clamp-2 pt-1">
                      {trip.journalNote}
                    </p>
                  )}
                </div>
              </div>

              <div className="px-5 py-3.5 border-t border-[#E5DFD3] bg-[#FBF9F5] flex items-center justify-between gap-2">
                {!isConfirming ? (
                  <>
                    <button
                      type="button"
                      onClick={() => onSelectTrip(trip.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                        isActive
                          ? "bg-[#1B4332] text-[#FBF9F5]"
                          : "bg-[#FFFFFF] text-[#1C1917] border border-[#D4CBB8] hover:bg-[#F3EFE6]"
                      }`}
                    >
                      <FolderOpen className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{isActive ? "편집 중 · 열기" : "저널 열기"}</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onDuplicateTrip(trip.id)}
                        title="여행 복제"
                        aria-label={`${trip.title} 복제`}
                        className="p-1.5 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      {trips.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(trip.id)}
                          title="여행 삭제"
                          aria-label={`${trip.title} 삭제`}
                          className="p-1.5 text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="w-full flex items-center justify-between gap-2">
                    <span className="text-xs text-[#B91C1C] font-medium">
                      정말 삭제할까요?
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="px-2.5 py-1 text-xs text-[#4A453F] border border-[#D4CBB8] bg-[#FFFFFF] rounded cursor-pointer"
                      >
                        취소
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteTrip(trip.id);
                          setConfirmDeleteId(null);
                        }}
                        className="px-2.5 py-1 text-xs text-[#FFFFFF] bg-[#B91C1C] rounded cursor-pointer"
                      >
                        삭제
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </main>
  );
}
