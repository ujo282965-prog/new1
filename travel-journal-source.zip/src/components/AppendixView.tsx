import {
  Check,
  CheckSquare,
  Copy,
  Plus,
  Square,
  Trash2,
  UserPlus,
} from "lucide-react";
import { useMemo, useState } from "react";
import type {
  ExpenseEntry,
  ItineraryCategory,
  PackingCategory,
  PackingItem,
  ReservationItem,
  ReservationType,
  Trip,
} from "../types/travel";
import { createId, formatWon } from "../utils/storage";

interface AppendixViewProps {
  trip: Trip;
  onUpdateTrip: (patch: Partial<Trip>) => void;
}

const EXPENSE_CATEGORIES: ItineraryCategory[] = [
  "숙소",
  "미식",
  "카페",
  "관광",
  "이동",
  "쇼핑",
  "휴식",
];

const PACKING_CATEGORIES: PackingCategory[] = [
  "필수 서류",
  "의류",
  "전자기기",
  "세면·상비약",
  "기타",
];

const RESERVATION_TYPES: ReservationType[] = [
  "항공·기차",
  "숙소",
  "투어·티켓",
  "식당·기타",
];

const DEFAULT_PACKING_PRESET: Array<{ label: string; category: PackingCategory }> = [
  { label: "여권 및 신분증 사본", category: "필수 서류" },
  { label: "해외 결제 카드 및 소액 현금", category: "필수 서류" },
  { label: "여분 상의·양말 및 편한 신발", category: "의류" },
  { label: "충전기 & 보조배터리", category: "전자기기" },
  { label: "개인 세면도구 & 상비약", category: "세면·상비약" },
];

interface SettlementTransfer {
  from: string;
  to: string;
  amount: number;
}

function computeSettlements(
  travelers: string[],
  expenses: ExpenseEntry[]
): {
  totalSpent: number;
  paidByPerson: Record<string, number>;
  shareByPerson: Record<string, number>;
  transfers: SettlementTransfer[];
} {
  const paidByPerson: Record<string, number> = {};
  const shareByPerson: Record<string, number> = {};
  travelers.forEach((name) => {
    paidByPerson[name] = 0;
    shareByPerson[name] = 0;
  });

  let totalSpent = 0;
  expenses.forEach((exp) => {
    if (exp.amount <= 0) return;
    totalSpent += exp.amount;
    paidByPerson[exp.paidBy] = (paidByPerson[exp.paidBy] ?? 0) + exp.amount;

    const participants =
      exp.splitAmong.length > 0 ? exp.splitAmong : travelers;
    const perPerson = exp.amount / participants.length;
    participants.forEach((p) => {
      shareByPerson[p] = (shareByPerson[p] ?? 0) + perPerson;
    });
  });

  const balances: Array<{ name: string; net: number }> = Object.keys({
    ...paidByPerson,
    ...shareByPerson,
  }).map((name) => ({
    name,
    net: Math.round((paidByPerson[name] ?? 0) - (shareByPerson[name] ?? 0)),
  }));

  const debtors = balances
    .filter((b) => b.net < -10)
    .map((b) => ({ name: b.name, amount: -b.net }))
    .sort((a, b) => b.amount - a.amount);
  const creditors = balances
    .filter((b) => b.net > 10)
    .map((b) => ({ name: b.name, amount: b.net }))
    .sort((a, b) => b.amount - a.amount);

  const transfers: SettlementTransfer[] = [];
  let i = 0;
  let j = 0;
  while (i < debtors.length && j < creditors.length) {
    const give = Math.min(debtors[i].amount, creditors[j].amount);
    if (give >= 10) {
      transfers.push({
        from: debtors[i].name,
        to: creditors[j].name,
        amount: Math.round(give),
      });
    }
    debtors[i].amount -= give;
    creditors[j].amount -= give;
    if (debtors[i].amount < 10) i++;
    if (creditors[j].amount < 10) j++;
  }

  return { totalSpent, paidByPerson, shareByPerson, transfers };
}

export function AppendixView({ trip, onUpdateTrip }: AppendixViewProps) {
  const [activeTab, setActiveTab] = useState<"budget" | "checklist">("budget");

  const travelers = useMemo(
    () => (trip.travelers && trip.travelers.length > 0 ? trip.travelers : ["나"]),
    [trip.travelers]
  );
  const expenses = useMemo(() => trip.expenses ?? [], [trip.expenses]);
  const packingList = useMemo(() => trip.packingList ?? [], [trip.packingList]);
  const reservations = useMemo(() => trip.reservations ?? [], [trip.reservations]);

  // Traveler form
  const [newTravelerName, setNewTravelerName] = useState("");

  // Expense form
  const [expTitle, setExpTitle] = useState("");
  const [expAmount, setExpAmount] = useState("");
  const [expCategory, setExpCategory] = useState<ItineraryCategory>("미식");
  const [expPaidBy, setExpPaidBy] = useState(travelers[0]);
  const [expDay, setExpDay] = useState(1);

  // Packing form
  const [packLabel, setPackLabel] = useState("");
  const [packCategory, setPackCategory] = useState<PackingCategory>("필수 서류");

  // Reservation form
  const [resType, setResType] = useState<ReservationType>("숙소");
  const [resTitle, setResTitle] = useState("");
  const [resDateTime, setResDateTime] = useState("");
  const [resCode, setResCode] = useState("");
  const [resLocation, setResLocation] = useState("");
  const [resNote, setResNote] = useState("");
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const settlement = useMemo(
    () => computeSettlements(travelers, expenses),
    [travelers, expenses]
  );

  const categoryTotals = useMemo(() => {
    const totals: Record<string, number> = {};
    expenses.forEach((e) => {
      totals[e.category] = (totals[e.category] ?? 0) + e.amount;
    });
    return Object.entries(totals).sort((a, b) => b[1] - a[1]);
  }, [expenses]);

  const plannedTotal = useMemo(
    () =>
      trip.days
        .flatMap((d) => d.items)
        .reduce((s, item) => s + (item.estimatedCost || 0), 0),
    [trip.days]
  );

  const handleAddTraveler = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newTravelerName.trim();
    if (!clean || travelers.includes(clean)) return;
    onUpdateTrip({ travelers: [...travelers, clean] });
    setNewTravelerName("");
  };

  const handleRemoveTraveler = (name: string) => {
    if (travelers.length <= 1) return;
    const next = travelers.filter((t) => t !== name);
    onUpdateTrip({ travelers: next });
    if (expPaidBy === name) setExpPaidBy(next[0]);
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Math.round(Number(expAmount));
    if (!expTitle.trim() || !amt || amt <= 0) return;
    const entry: ExpenseEntry = {
      id: createId("exp"),
      title: expTitle.trim(),
      amount: amt,
      category: expCategory,
      paidBy: travelers.includes(expPaidBy) ? expPaidBy : travelers[0],
      splitAmong: travelers,
      dayNumber: expDay,
      note: "",
    };
    onUpdateTrip({ expenses: [entry, ...expenses] });
    setExpTitle("");
    setExpAmount("");
  };

  const handleDeleteExpense = (id: string) => {
    onUpdateTrip({ expenses: expenses.filter((e) => e.id !== id) });
  };

  const handleAddPacking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!packLabel.trim()) return;
    const item: PackingItem = {
      id: createId("pack"),
      label: packLabel.trim(),
      category: packCategory,
      checked: false,
    };
    onUpdateTrip({ packingList: [...packingList, item] });
    setPackLabel("");
  };

  const handleTogglePacking = (id: string) => {
    onUpdateTrip({
      packingList: packingList.map((p) =>
        p.id === id ? { ...p, checked: !p.checked } : p
      ),
    });
  };

  const handleDeletePacking = (id: string) => {
    onUpdateTrip({ packingList: packingList.filter((p) => p.id !== id) });
  };

  const handleLoadPackingPresets = () => {
    const existing = new Set(packingList.map((p) => p.label));
    const additions: PackingItem[] = DEFAULT_PACKING_PRESET.filter(
      (p) => !existing.has(p.label)
    ).map((p) => ({
      id: createId("pack"),
      label: p.label,
      category: p.category,
      checked: false,
    }));
    if (additions.length > 0) {
      onUpdateTrip({ packingList: [...packingList, ...additions] });
    }
  };

  const handleAddReservation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resTitle.trim()) return;
    const item: ReservationItem = {
      id: createId("res"),
      type: resType,
      title: resTitle.trim(),
      dateTime: resDateTime.trim(),
      confirmationCode: resCode.trim(),
      location: resLocation.trim(),
      note: resNote.trim(),
    };
    onUpdateTrip({ reservations: [item, ...reservations] });
    setResTitle("");
    setResDateTime("");
    setResCode("");
    setResLocation("");
    setResNote("");
  };

  const handleDeleteReservation = (id: string) => {
    onUpdateTrip({ reservations: reservations.filter((r) => r.id !== id) });
  };

  const handleCopyCode = async (id: string, code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCodeId(id);
      setTimeout(() => setCopiedCodeId(null), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  return (
    <main className="max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-[#E5DFD3]">
        <div>
          <p className="font-mono-tabular text-xs text-[#1B4332]">
            JOURNAL APPENDIX · {trip.destination}
          </p>
          <h1 className="mt-1 font-editorial text-3xl font-semibold text-[#1C1917]">
            경비 정산 및 준비물 부록
          </h1>
          <p className="mt-1 text-sm text-[#6B655E]">
            동행자와의 공동 경비 정산 내역과 예약 바우처, 짐 싸기 체크리스트를 관리합니다.
          </p>
        </div>

        <div className="inline-flex p-1 bg-[#F3EFE6] border border-[#E5DFD3] rounded-md shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("budget")}
            className={`px-4 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === "budget"
                ? "bg-[#FFFFFF] text-[#1C1917] shadow-xs"
                : "text-[#6B655E] hover:text-[#1C1917]"
            }`}
          >
            경비 정산 ({expenses.length}건)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("checklist")}
            className={`px-4 py-1.5 text-xs font-medium rounded transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === "checklist"
                ? "bg-[#FFFFFF] text-[#1C1917] shadow-xs"
                : "text-[#6B655E] hover:text-[#1C1917]"
            }`}
          >
            예약 & 체크리스트 ({reservations.length + packingList.length})
          </button>
        </div>
      </div>

      {activeTab === "budget" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left 7 cols: Expense Log & Form */}
          <div className="lg:col-span-7 space-y-6">
            {/* Summary Metrics */}
            <div className="grid grid-cols-3 gap-4 border-y border-[#E5DFD3] py-5">
              <div>
                <p className="text-xs text-[#6B655E]">실제 지출 합계</p>
                <p className="mt-1 font-mono-tabular text-xl font-semibold text-[#1C1917]">
                  {formatWon(settlement.totalSpent)}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#6B655E]">1인당 평균 ({travelers.length}명)</p>
                <p className="mt-1 font-mono-tabular text-xl font-semibold text-[#1B4332]">
                  {formatWon(
                    Math.round(settlement.totalSpent / Math.max(1, travelers.length))
                  )}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#6B655E]">일정표 1인 예상 합계</p>
                <p className="mt-1 font-mono-tabular text-xl font-semibold text-[#6B655E]">
                  {formatWon(plannedTotal)}
                </p>
              </div>
            </div>

            {/* Add Expense Form */}
            <form
              onSubmit={handleAddExpense}
              className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-3"
            >
              <h2 className="font-editorial text-lg font-semibold text-[#1C1917]">
                새 지출 기록하기
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  value={expTitle}
                  onChange={(e) => setExpTitle(e.target.value)}
                  placeholder="지출 내용 (예: 저녁 식사, 택시비)"
                  className="px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                />
                <input
                  type="number"
                  required
                  min={100}
                  step={100}
                  value={expAmount}
                  onChange={(e) => setExpAmount(e.target.value)}
                  placeholder="금액 (원)"
                  className="px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <label className="block">
                  <span className="text-[11px] text-[#6B655E]">카테고리</span>
                  <select
                    value={expCategory}
                    onChange={(e) =>
                      setExpCategory(e.target.value as ItineraryCategory)
                    }
                    className="mt-1 w-full px-2.5 py-1.5 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                  >
                    {EXPENSE_CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="text-[11px] text-[#6B655E]">결제한 사람</span>
                  <select
                    value={expPaidBy}
                    onChange={(e) => setExpPaidBy(e.target.value)}
                    className="mt-1 w-full px-2.5 py-1.5 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                  >
                    {travelers.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="text-[11px] text-[#6B655E]">일차</span>
                  <select
                    value={expDay}
                    onChange={(e) => setExpDay(Number(e.target.value))}
                    className="mt-1 w-full px-2.5 py-1.5 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular"
                  >
                    {trip.days.map((d) => (
                      <option key={d.dayNumber} value={d.dayNumber}>
                        Day {d.dayNumber}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>지출 추가 ({travelers.length}명 균등 정산)</span>
                </button>
              </div>
            </form>

            {/* Expense List */}
            {expenses.length === 0 ? (
              <div className="py-10 text-center border border-dashed border-[#D4CBB8] text-sm text-[#6B655E]">
                아직 기록된 지출이 없습니다. 위 양식에서 첫 지출을 기록해 보세요.
              </div>
            ) : (
              <div className="divide-y divide-[#E5DFD3] border-b border-[#E5DFD3]">
                {expenses.map((exp) => (
                  <div
                    key={exp.id}
                    className="py-3.5 flex items-center justify-between gap-4"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#1C1917] truncate">
                        {exp.title}
                      </p>
                      <p className="mt-0.5 text-xs text-[#6B655E]">
                        Day {String(exp.dayNumber).padStart(2, "0")} · {exp.category} · 결제:{" "}
                        <span className="text-[#1C1917] font-medium">{exp.paidBy}</span>
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="font-mono-tabular text-sm font-semibold text-[#1C1917]">
                        {formatWon(exp.amount)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeleteExpense(exp.id)}
                        aria-label="지출 삭제"
                        className="p-1.5 text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right 5 cols: Travelers & Settlement */}
          <div className="lg:col-span-5 space-y-6">
            {/* Travelers Management */}
            <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-4">
              <div>
                <h2 className="font-editorial text-lg font-semibold text-[#1C1917]">
                  동행자 명단 ({travelers.length}명)
                </h2>
                <p className="text-xs text-[#6B655E] mt-0.5">
                  정산에 참여하는 친구·가족 이름을 관리하세요.
                </p>
              </div>

              <div className="divide-y divide-[#E5DFD3] bg-[#FFFFFF] border border-[#E5DFD3] px-3">
                {travelers.map((name) => (
                  <div
                    key={name}
                    className="py-2.5 flex items-center justify-between gap-2 text-sm"
                  >
                    <span className="font-medium text-[#1C1917]">{name}</span>
                    <div className="flex items-center gap-3">
                      <span className="font-mono-tabular text-xs text-[#6B655E]">
                        결제 {formatWon(settlement.paidByPerson[name] ?? 0)}
                      </span>
                      {travelers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveTraveler(name)}
                          className="text-xs text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                        >
                          제외
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <form onSubmit={handleAddTraveler} className="flex gap-2">
                <input
                  type="text"
                  value={newTravelerName}
                  onChange={(e) => setNewTravelerName(e.target.value)}
                  placeholder="동행자 이름 추가"
                  className="flex-1 px-3 py-1.5 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                />
                <button
                  type="submit"
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-[#1C1917] text-[#FBF9F5] rounded-md cursor-pointer shrink-0"
                >
                  <UserPlus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>추가</span>
                </button>
              </form>
            </div>

            {/* Settlement Result */}
            <div className="border border-[#E5DFD3] bg-[#FFFFFF] p-5 space-y-4">
              <div className="pb-3 border-b border-[#E5DFD3]">
                <p className="font-mono-tabular text-[11px] text-[#1B4332]">
                  SETTLEMENT SUMMARY
                </p>
                <h3 className="font-editorial text-lg font-semibold text-[#1C1917]">
                  1/N 정산 이체 안내
                </h3>
              </div>

              {settlement.transfers.length === 0 ? (
                <p className="text-xs text-[#6B655E]">
                  정산할 차액이 없거나 지출 내역이 아직 없습니다.
                </p>
              ) : (
                <div className="divide-y divide-[#E5DFD3]">
                  {settlement.transfers.map((tr, idx) => (
                    <div
                      key={idx}
                      className="py-2.5 flex items-center justify-between text-sm"
                    >
                      <span>
                        <strong className="text-[#1C1917]">{tr.from}</strong>
                        <span className="text-[#6B655E] mx-2">→</span>
                        <strong className="text-[#1B4332]">{tr.to}</strong>
                      </span>
                      <span className="font-mono-tabular font-semibold text-[#1C1917]">
                        {formatWon(tr.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {categoryTotals.length > 0 && (
                <div className="pt-4 border-t border-[#E5DFD3] space-y-2.5">
                  <p className="text-xs font-semibold text-[#6B655E]">
                    카테고리별 지출 비중
                  </p>
                  {categoryTotals.map(([cat, amt]) => {
                    const pct =
                      settlement.totalSpent > 0
                        ? Math.round((amt / settlement.totalSpent) * 100)
                        : 0;
                    return (
                      <div key={cat} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#1C1917]">{cat}</span>
                          <span className="font-mono-tabular text-[#6B655E]">
                            {formatWon(amt)} ({pct}%)
                          </span>
                        </div>
                        <div className="h-1.5 bg-[#F3EFE6] overflow-hidden">
                          <div
                            className="h-full bg-[#1B4332]"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left 6 cols: Reservations & Vouchers */}
          <div className="lg:col-span-6 space-y-5">
            <div className="pb-3 border-b border-[#E5DFD3]">
              <h2 className="font-editorial text-2xl font-semibold text-[#1C1917]">
                예약 정보 & 바우처 노트
              </h2>
              <p className="text-xs text-[#6B655E] mt-1">
                항공편·숙소 체크인 번호·예약 확정 코드를 저장해 두고 필요할 때 바로 복사하세요.
              </p>
            </div>

            <form
              onSubmit={handleAddReservation}
              className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <select
                  value={resType}
                  onChange={(e) => setResType(e.target.value as ReservationType)}
                  className="px-2.5 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                >
                  {RESERVATION_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
                <input
                  type="text"
                  required
                  value={resTitle}
                  onChange={(e) => setResTitle(e.target.value)}
                  placeholder="예약 제목 (예: 하네다행 항공)"
                  className="sm:col-span-2 px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  value={resDateTime}
                  onChange={(e) => setResDateTime(e.target.value)}
                  placeholder="일시 (예: 11/12 15:00)"
                  className="px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular"
                />
                <input
                  type="text"
                  value={resCode}
                  onChange={(e) => setResCode(e.target.value)}
                  placeholder="예약번호 / 코드"
                  className="px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular"
                />
                <input
                  type="text"
                  value={resLocation}
                  onChange={(e) => setResLocation(e.target.value)}
                  placeholder="위치 / 터미널"
                  className="px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                />
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={resNote}
                  onChange={(e) => setResNote(e.target.value)}
                  placeholder="참고 메모 (체크인 안내 등)"
                  className="flex-1 px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
                />
                <button
                  type="submit"
                  className="inline-flex items-center gap-1 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md cursor-pointer shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>추가</span>
                </button>
              </div>
            </form>

            {reservations.length === 0 ? (
              <div className="py-10 text-center border border-dashed border-[#D4CBB8] text-sm text-[#6B655E]">
                등록된 예약 정보가 없습니다.
              </div>
            ) : (
              <div className="divide-y divide-[#E5DFD3] border border-[#E5DFD3] bg-[#FFFFFF] px-5">
                {reservations.map((res) => (
                  <div key={res.id} className="py-4 space-y-1.5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs text-[#8C4A27] font-medium">
                          {res.type}
                          {res.dateTime ? ` · ${res.dateTime}` : ""}
                        </p>
                        <h3 className="text-sm font-semibold text-[#1C1917] mt-0.5">
                          {res.title}
                        </h3>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteReservation(res.id)}
                        aria-label="예약 삭제"
                        className="p-1 text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#6B655E]">
                      {res.location && <span>위치: {res.location}</span>}
                      {res.confirmationCode && (
                        <button
                          type="button"
                          onClick={() => handleCopyCode(res.id, res.confirmationCode)}
                          className="inline-flex items-center gap-1 font-mono-tabular text-[#1B4332] hover:underline cursor-pointer"
                        >
                          <span>코드: {res.confirmationCode}</span>
                          {copiedCodeId === res.id ? (
                            <Check className="w-3 h-3" aria-hidden="true" />
                          ) : (
                            <Copy className="w-3 h-3" aria-hidden="true" />
                          )}
                        </button>
                      )}
                    </div>

                    {res.note && (
                      <p className="text-xs text-[#4A453F]">{res.note}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right 6 cols: Packing Checklist */}
          <div className="lg:col-span-6 space-y-5">
            <div className="flex items-end justify-between gap-3 pb-3 border-b border-[#E5DFD3]">
              <div>
                <h2 className="font-editorial text-2xl font-semibold text-[#1C1917]">
                  짐 싸기 체크리스트
                </h2>
                <p className="text-xs text-[#6B655E] mt-1 font-mono-tabular">
                  {packingList.filter((p) => p.checked).length} / {packingList.length} 준비 완료
                </p>
              </div>
              <button
                type="button"
                onClick={handleLoadPackingPresets}
                className="px-3 py-1.5 text-xs font-medium text-[#1B4332] border border-[#1B4332]/35 rounded-md hover:bg-[#1B4332]/5 cursor-pointer whitespace-nowrap"
              >
                기본 준비물 채우기
              </button>
            </div>

            <form onSubmit={handleAddPacking} className="flex gap-2">
              <select
                value={packCategory}
                onChange={(e) => setPackCategory(e.target.value as PackingCategory)}
                className="px-2.5 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md"
              >
                {PACKING_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <input
                type="text"
                required
                value={packLabel}
                onChange={(e) => setPackLabel(e.target.value)}
                placeholder="챙길 물건 입력 (예: 선글라스, 우비)"
                className="flex-1 px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md cursor-pointer shrink-0"
              >
                <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                <span>추가</span>
              </button>
            </form>

            {packingList.length === 0 ? (
              <div className="py-10 text-center border border-dashed border-[#D4CBB8] text-sm text-[#6B655E]">
                체크리스트가 비어 있습니다. ‘기본 준비물 채우기’를 눌러 시작해 보세요.
              </div>
            ) : (
              <div className="divide-y divide-[#E5DFD3] border border-[#E5DFD3] bg-[#FFFFFF] px-4">
                {packingList.map((item) => (
                  <div
                    key={item.id}
                    className="py-3 flex items-center justify-between gap-3"
                  >
                    <button
                      type="button"
                      onClick={() => handleTogglePacking(item.id)}
                      className="flex items-center gap-3 text-left flex-1 min-w-0 cursor-pointer"
                    >
                      {item.checked ? (
                        <CheckSquare className="w-4 h-4 text-[#1B4332] shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-[#6B655E] shrink-0" />
                      )}
                      <span
                        className={`text-sm truncate ${
                          item.checked
                            ? "line-through text-[#6B655E]"
                            : "text-[#1C1917]"
                        }`}
                      >
                        {item.label}
                      </span>
                    </button>

                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-[11px] text-[#6B655E]">
                        {item.category}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleDeletePacking(item.id)}
                        aria-label="준비물 삭제"
                        className="p-1 text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
