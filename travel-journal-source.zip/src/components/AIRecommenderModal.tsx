import { Check, Loader2, Sparkles, X } from "lucide-react";
import { useState } from "react";
import { COVER_PRESETS } from "../data/seedTrips";
import type {
  AIRecommendResponse,
  CompanionType,
  PaceType,
} from "../types/travel";
import { requestAIItinerary } from "../utils/api";
import { formatWon } from "../utils/storage";
import { CoverImage } from "./CoverImage";

interface AIRecommenderModalProps {
  isOpen: boolean;
  hasActiveTrip: boolean;
  onClose: () => void;
  onCreateNewTripFromAI: (
    result: AIRecommendResponse,
    meta: {
      destination: string;
      companions: CompanionType;
      pace: PaceType;
      coverImage: string;
      coverCaption: string;
    }
  ) => void;
  onApplyToCurrentTrip: (result: AIRecommendResponse) => void;
}

const COMPANION_OPTIONS: CompanionType[] = ["혼자", "친구", "가족", "연인"];
const PACE_OPTIONS: PaceType[] = ["여유롭게", "균형 있게", "알차게"];
const THEME_OPTIONS = [
  "로컬 산책",
  "미식·노포",
  "카페·다실",
  "미술관·건축",
  "자연·풍경",
  "독립서점·공예",
];

export function AIRecommenderModal({
  isOpen,
  hasActiveTrip,
  onClose,
  onCreateNewTripFromAI,
  onApplyToCurrentTrip,
}: AIRecommenderModalProps) {
  const [destination, setDestination] = useState("포르투, 포르투갈");
  const [daysCount, setDaysCount] = useState(3);
  const [companions, setCompanions] = useState<CompanionType>("친구");
  const [pace, setPace] = useState<PaceType>("균형 있게");
  const [themes, setThemes] = useState<string[]>(["로컬 산책", "카페·다실"]);
  const [extraNotes, setExtraNotes] = useState("");
  const [selectedCoverIndex, setSelectedCoverIndex] = useState(3);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<AIRecommendResponse | null>(null);

  if (!isOpen) return null;

  const toggleTheme = (theme: string) => {
    setThemes((prev) =>
      prev.includes(theme) ? prev.filter((t) => t !== theme) : [...prev, theme]
    );
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim()) {
      setError("여행지를 입력해 주세요.");
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const data = await requestAIItinerary({
        destination: destination.trim(),
        daysCount,
        companions,
        pace,
        themes,
        extraNotes: extraNotes.trim(),
      });
      setPreview(data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "AI 코스 생성 중 오류가 발생했습니다."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const chosenCover = COVER_PRESETS[selectedCoverIndex] ?? COVER_PRESETS[0];

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1C1917]/50 backdrop-blur-[2px] flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-modal-title"
    >
      <div className="w-full max-w-5xl bg-[#FBF9F5] border border-[#D4CBB8] shadow-xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E5DFD3] flex items-center justify-between gap-4 shrink-0">
          <div>
            <p className="font-mono-tabular text-[11px] text-[#1B4332]">
              CURATED ITINERARY GENERATOR
            </p>
            <h2
              id="ai-modal-title"
              className="font-editorial text-xl font-semibold text-[#1C1917]"
            >
              AI 맞춤 여행 코스 추천
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="p-2 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 2-Column Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12">
          {/* Left Form */}
          <form
            onSubmit={handleGenerate}
            className="lg:col-span-5 p-6 bg-[#F3EFE6] border-b lg:border-b-0 lg:border-r border-[#E5DFD3] space-y-5"
          >
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">여행지</span>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="예: 교토, 리스본, 강릉, 타이베이"
                required
                className="mt-1.5 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs font-semibold text-[#1C1917]">여행 일수</span>
                <select
                  value={daysCount}
                  onChange={(e) => setDaysCount(Number(e.target.value))}
                  className="mt-1.5 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
                >
                  {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                    <option key={n} value={n}>
                      {n === 1 ? "당일치기 (1일)" : `${n - 1}박 ${n}일`}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block">
                <span className="text-xs font-semibold text-[#1C1917]">동행 구성</span>
                <select
                  value={companions}
                  onChange={(e) => setCompanions(e.target.value as CompanionType)}
                  className="mt-1.5 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                >
                  {COMPANION_OPTIONS.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#1C1917]">일정 밀도</span>
              <div className="mt-1.5 grid grid-cols-3 gap-1.5">
                {PACE_OPTIONS.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setPace(opt)}
                    className={`py-2 px-2 text-xs font-medium rounded-md border transition-colors cursor-pointer whitespace-nowrap ${
                      pace === opt
                        ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                        : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8] hover:border-[#1C1917]"
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#1C1917]">
                선호 테마 (복수 선택)
              </span>
              <div className="mt-1.5 grid grid-cols-2 gap-1.5">
                {THEME_OPTIONS.map((theme) => {
                  const active = themes.includes(theme);
                  return (
                    <button
                      key={theme}
                      type="button"
                      onClick={() => toggleTheme(theme)}
                      className={`py-1.5 px-2.5 text-xs text-left rounded-md border transition-colors cursor-pointer flex items-center justify-between ${
                        active
                          ? "bg-[#1C1917] text-[#FBF9F5] border-[#1C1917]"
                          : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8] hover:border-[#1C1917]"
                      }`}
                    >
                      <span>{theme}</span>
                      {active && <Check className="w-3 h-3 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#1C1917]">커버 이미지 분위기</span>
              <div className="mt-1.5 grid grid-cols-4 gap-2">
                {COVER_PRESETS.map((preset, idx) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setSelectedCoverIndex(idx)}
                    title={preset.label}
                    className={`border p-0.5 bg-[#FFFFFF] cursor-pointer ${
                      selectedCoverIndex === idx
                        ? "border-[#1B4332] ring-1 ring-[#1B4332]"
                        : "border-[#D4CBB8]"
                    }`}
                  >
                    <div className="aspect-[16/10] overflow-hidden">
                      <CoverImage
                        src={preset.image}
                        alt={preset.label}
                        className="w-full h-full"
                      />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">
                세부 요청사항 (선택)
              </span>
              <textarea
                rows={2}
                value={extraNotes}
                onChange={(e) => setExtraNotes(e.target.value)}
                placeholder="예: 걷기 편한 동선 위주, 저녁엔 분위기 좋은 와인바 포함"
                className="mt-1.5 w-full px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] disabled:opacity-60 transition-colors cursor-pointer"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
                  <span>맞춤 여행 코스를 엮는 중...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" aria-hidden="true" />
                  <span>AI 코스 추천받기</span>
                </>
              )}
            </button>
          </form>

          {/* Right Preview */}
          <div className="lg:col-span-7 p-6 flex flex-col justify-between bg-[#FBF9F5]">
            {error && (
              <div className="mb-4 p-4 bg-[#FFFFFF] border border-[#B91C1C]/40 text-sm text-[#B91C1C] flex items-start justify-between gap-4">
                <p className="leading-relaxed">{error}</p>
                <button
                  type="button"
                  onClick={handleGenerate}
                  className="text-xs font-medium underline shrink-0 cursor-pointer"
                >
                  다시 시도
                </button>
              </div>
            )}

            {isLoading && (
              <div className="space-y-6 animate-pulse">
                <div className="space-y-2 border-b border-[#E5DFD3] pb-4">
                  <div className="h-3 w-28 bg-[#E5DFD3]" />
                  <div className="h-7 w-2/3 bg-[#E5DFD3]" />
                  <div className="h-4 w-full bg-[#F3EFE6]" />
                </div>
                {[1, 2].map((d) => (
                  <div key={d} className="space-y-3">
                    <div className="h-5 w-44 bg-[#E5DFD3]" />
                    <div className="h-16 w-full bg-[#F3EFE6]" />
                    <div className="h-16 w-full bg-[#F3EFE6]" />
                  </div>
                ))}
              </div>
            )}

            {!isLoading && !preview && (
              <div className="my-auto py-12 text-center max-w-md mx-auto space-y-3">
                <p className="font-mono-tabular text-xs text-[#6B655E]">
                  EDITORIAL COURSE PREVIEW
                </p>
                <h3 className="font-editorial text-2xl text-[#1C1917] text-balance">
                  여행의 조건을 들려주시면 일자별 코스를 구성해 드립니다
                </h3>
                <p className="text-sm text-[#6B655E] leading-relaxed">
                  왼쪽에서 여행지와 기간, 동행 취향을 고른 뒤 추천받기를 눌러보세요. 생성된 코스는 바로 검토하고 내 저널에 저장해 자유롭게 수정할 수 있습니다.
                </p>
              </div>
            )}

            {!isLoading && preview && (
              <div className="space-y-6">
                <div className="border-b border-[#E5DFD3] pb-5">
                  <p className="font-mono-tabular text-xs text-[#1B4332]">
                    {destination} · {daysCount}일간 여정 초안
                  </p>
                  <h3 className="mt-1 font-editorial text-2xl font-semibold text-[#1C1917] text-balance">
                    {preview.title}
                  </h3>
                  <p className="mt-2 text-sm text-[#4A453F] leading-relaxed">
                    {preview.journalNote}
                  </p>
                </div>

                <div className="space-y-6">
                  {preview.days.map((day) => (
                    <div key={day.dayNumber} className="space-y-3">
                      <div className="border-b border-[#E5DFD3] pb-2">
                        <span className="font-mono-tabular text-xs font-medium text-[#1B4332]">
                          Day {String(day.dayNumber).padStart(2, "0")}
                        </span>
                        <h4 className="font-editorial text-lg font-semibold text-[#1C1917]">
                          {day.title}
                        </h4>
                        {day.summary && (
                          <p className="text-xs text-[#6B655E] mt-0.5">{day.summary}</p>
                        )}
                      </div>

                      <div className="divide-y divide-[#E5DFD3]">
                        {day.items.map((item, idx) => (
                          <div key={idx} className="py-2.5 flex items-start gap-4">
                            <span className="font-mono-tabular text-xs font-medium text-[#1C1917] w-12 shrink-0 pt-0.5">
                              {item.time}
                            </span>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-[#1C1917]">
                                {item.title}
                              </p>
                              <p className="text-xs text-[#6B655E] mt-0.5">
                                {item.category} · {item.area} · {item.durationMinutes}분 ·{" "}
                                {formatWon(item.estimatedCost)}
                              </p>
                              <p className="text-xs text-[#4A453F] mt-1 leading-relaxed">
                                {item.note}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-5 border-t border-[#E5DFD3] flex flex-wrap items-center justify-end gap-3 sticky bottom-0 bg-[#FBF9F5] py-3">
                  {hasActiveTrip && (
                    <button
                      type="button"
                      onClick={() => onApplyToCurrentTrip(preview)}
                      className="px-4 py-2 text-xs font-medium text-[#1C1917] border border-[#D4CBB8] bg-[#FFFFFF] rounded-md hover:bg-[#F3EFE6] cursor-pointer"
                    >
                      현재 열려있는 여행에 일정 덮어쓰기
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() =>
                      onCreateNewTripFromAI(preview, {
                        destination: destination.trim(),
                        companions,
                        pace,
                        coverImage: chosenCover.image,
                        coverCaption: chosenCover.caption,
                      })
                    }
                    className="px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
                  >
                    새 여행 저널로 저장하기
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
