import {
  ArrowDown,
  ArrowUp,
  Check,
  CheckCircle2,
  Circle,
  CloudRain,
  Coffee,
  Loader2,
  MapPinned,
  Plus,
  Route as RouteIcon,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { useState } from "react";
import type {
  AIDayRebalanceResponse,
  ItineraryItem,
  RebalanceMode,
  TripDay,
} from "../types/travel";
import { requestAIDayRebalance } from "../utils/api";
import { formatWon } from "../utils/storage";

interface TimelineSectionProps {
  destination: string;
  companions: string;
  days: TripDay[];
  selectedDayFilter: number | "all";
  selectedItemId: string | null;
  onSelectItem: (dayNumber: number, itemId: string) => void;
  onToggleComplete: (dayNumber: number, itemId: string) => void;
  onMoveItem: (dayNumber: number, itemId: string, direction: "up" | "down") => void;
  onDeleteItem: (dayNumber: number, itemId: string) => void;
  onAddItem: (dayNumber: number) => void;
  onUpdateDayMeta: (dayNumber: number, patch: { title?: string; summary?: string }) => void;
  onDeleteDay: (dayNumber: number) => void;
  canDeleteDay: boolean;
  onRequestDayAISuggest: (dayNumber: number) => void;
  onApplyRebalancedDay: (dayNumber: number, result: AIDayRebalanceResponse) => void;
  onOpenDayOnMap: (dayNumber: number) => void;
}

export function TimelineSection({
  destination,
  companions,
  days,
  selectedDayFilter,
  selectedItemId,
  onSelectItem,
  onToggleComplete,
  onMoveItem,
  onDeleteItem,
  onAddItem,
  onUpdateDayMeta,
  onDeleteDay,
  canDeleteDay,
  onRequestDayAISuggest,
  onApplyRebalancedDay,
  onOpenDayOnMap,
}: TimelineSectionProps) {
  const [editingDayNum, setEditingDayNum] = useState<number | null>(null);
  const [draftTitle, setDraftTitle] = useState("");
  const [draftSummary, setDraftSummary] = useState("");

  const [rebalanceLoadingDay, setRebalanceLoadingDay] = useState<number | null>(null);
  const [rebalanceError, setRebalanceError] = useState<{
    dayNumber: number;
    message: string;
  } | null>(null);
  const [rebalancePreview, setRebalancePreview] = useState<{
    dayNumber: number;
    result: AIDayRebalanceResponse;
  } | null>(null);

  const visibleDays =
    selectedDayFilter === "all"
      ? days
      : days.filter((d) => d.dayNumber === selectedDayFilter);

  const startDayEdit = (day: TripDay) => {
    setEditingDayNum(day.dayNumber);
    setDraftTitle(day.title);
    setDraftSummary(day.summary);
  };

  const saveDayEdit = (dayNumber: number) => {
    onUpdateDayMeta(dayNumber, {
      title: draftTitle.trim() || `Day ${dayNumber}`,
      summary: draftSummary.trim(),
    });
    setEditingDayNum(null);
  };

  const handleRebalance = async (day: TripDay, mode: RebalanceMode) => {
    if (day.items.length === 0) return;
    setRebalanceLoadingDay(day.dayNumber);
    setRebalanceError(null);
    setRebalancePreview(null);
    try {
      const result = await requestAIDayRebalance({
        destination,
        dayNumber: day.dayNumber,
        dayTitle: day.title,
        companions,
        mode,
        items: day.items,
      });
      setRebalancePreview({ dayNumber: day.dayNumber, result });
    } catch (err) {
      setRebalanceError({
        dayNumber: day.dayNumber,
        message:
          err instanceof Error
            ? err.message
            : "일정 리밸런싱 요청에 실패했습니다.",
      });
    } finally {
      setRebalanceLoadingDay(null);
    }
  };

  return (
    <div className="flex-1 min-w-0 space-y-8">
      {visibleDays.map((day) => {
        const dayCode = String(day.dayNumber).padStart(2, "0");
        const isEditingThisDay = editingDayNum === day.dayNumber;
        const isRebalancingThisDay = rebalanceLoadingDay === day.dayNumber;
        const dayError =
          rebalanceError?.dayNumber === day.dayNumber ? rebalanceError.message : null;
        const dayPreview =
          rebalancePreview?.dayNumber === day.dayNumber
            ? rebalancePreview.result
            : null;

        return (
          <section key={day.dayNumber} className="space-y-4">
            {/* Day Chapter Header */}
            <div className="pb-4 border-b border-[#1C1917]/20">
              {!isEditingThisDay ? (
                <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                  <div>
                    <p className="font-mono-tabular text-xs font-medium tracking-wider text-[#1B4332]">
                      Chapter {dayCode}
                    </p>
                    <h2 className="mt-1 font-editorial text-2xl font-semibold text-[#1C1917] text-balance">
                      {day.title || `${day.dayNumber}일차 여정`}
                    </h2>
                    {day.summary && (
                      <p className="mt-1.5 text-sm text-[#6B655E] leading-relaxed max-w-2xl">
                        {day.summary}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenDayOnMap(day.dayNumber)}
                      className="inline-flex items-center gap-1 text-xs font-medium text-[#1B4332] hover:underline underline-offset-4 cursor-pointer whitespace-nowrap"
                    >
                      <MapPinned className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>지도 동선</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => startDayEdit(day)}
                      className="text-xs font-medium text-[#6B655E] hover:text-[#1C1917] underline-offset-4 hover:underline cursor-pointer whitespace-nowrap"
                    >
                      챕터 제목 수정
                    </button>
                    {canDeleteDay && (
                      <button
                        type="button"
                        onClick={() => onDeleteDay(day.dayNumber)}
                        className="text-xs font-medium text-[#6B655E] hover:text-[#B91C1C] cursor-pointer whitespace-nowrap"
                      >
                        일차 삭제
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-4 space-y-3">
                  <label className="block">
                    <span className="text-xs font-medium text-[#6B655E]">
                      Day {dayCode} 소제목
                    </span>
                    <input
                      type="text"
                      value={draftTitle}
                      onChange={(e) => setDraftTitle(e.target.value)}
                      className="mt-1 w-full px-3 py-1.5 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                    />
                  </label>
                  <label className="block">
                    <span className="text-xs font-medium text-[#6B655E]">
                      동선 요약 한 줄
                    </span>
                    <input
                      type="text"
                      value={draftSummary}
                      onChange={(e) => setDraftSummary(e.target.value)}
                      className="mt-1 w-full px-3 py-1.5 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                    />
                  </label>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingDayNum(null)}
                      className="px-3 py-1.5 text-xs text-[#4A453F] border border-[#D4CBB8] bg-[#FFFFFF] rounded-md cursor-pointer"
                    >
                      취소
                    </button>
                    <button
                      type="button"
                      onClick={() => saveDayEdit(day.dayNumber)}
                      className="px-3 py-1.5 text-xs font-medium text-[#FBF9F5] bg-[#1B4332] rounded-md cursor-pointer"
                    >
                      저장
                    </button>
                  </div>
                </div>
              )}

              {/* AI Rebalance Toolbar when items exist */}
              {day.items.length >= 2 && (
                <div className="mt-3 pt-3 border-t border-[#E5DFD3] flex flex-wrap items-center gap-2">
                  <span className="text-[11px] font-medium text-[#6B655E] mr-1">
                    AI 일정 리밸런싱:
                  </span>
                  <button
                    type="button"
                    disabled={isRebalancingThisDay}
                    onClick={() => handleRebalance(day, "optimize_route")}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-[#1C1917] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] disabled:opacity-50 cursor-pointer whitespace-nowrap"
                  >
                    <RouteIcon className="w-3 h-3 text-[#1B4332]" aria-hidden="true" />
                    <span>동선·시간 최적화</span>
                  </button>
                  <button
                    type="button"
                    disabled={isRebalancingThisDay}
                    onClick={() => handleRebalance(day, "rainy_indoor")}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-[#1C1917] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] disabled:opacity-50 cursor-pointer whitespace-nowrap"
                  >
                    <CloudRain className="w-3 h-3 text-[#8C4A27]" aria-hidden="true" />
                    <span>비 오는 날 실내 전환</span>
                  </button>
                  <button
                    type="button"
                    disabled={isRebalancingThisDay}
                    onClick={() => handleRebalance(day, "relaxed_pace")}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-[#1C1917] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] disabled:opacity-50 cursor-pointer whitespace-nowrap"
                  >
                    <Coffee className="w-3 h-3 text-[#6B655E]" aria-hidden="true" />
                    <span>여유롭게 재조정</span>
                  </button>
                  {isRebalancingThisDay && (
                    <span className="inline-flex items-center gap-1 text-xs text-[#1B4332]">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                      <span>재구성 중...</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            {dayError && (
              <div className="p-3 bg-[#FFFFFF] border border-[#B91C1C]/40 text-xs text-[#B91C1C] flex items-center justify-between gap-3">
                <span>{dayError}</span>
                <button
                  type="button"
                  onClick={() => setRebalanceError(null)}
                  className="p-1 hover:text-[#1C1917] cursor-pointer"
                  aria-label="오류 닫기"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* AI Rebalance Preview Box */}
            {dayPreview && (
              <div className="bg-[#F3EFE6] border border-[#1B4332]/40 p-5 space-y-4">
                <div className="flex items-start justify-between gap-4 border-b border-[#E5DFD3] pb-3">
                  <div>
                    <p className="font-mono-tabular text-[11px] font-medium text-[#1B4332]">
                      AI 리밸런싱 제안 미리보기
                    </p>
                    <h3 className="mt-0.5 font-editorial text-lg font-semibold text-[#1C1917]">
                      {dayPreview.title}
                    </h3>
                    <p className="mt-1 text-xs text-[#4A453F] leading-relaxed">
                      {dayPreview.reason}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setRebalancePreview(null)}
                    aria-label="제안 닫기"
                    className="p-1 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="divide-y divide-[#E5DFD3] bg-[#FFFFFF] border border-[#E5DFD3] px-4">
                  {dayPreview.items.map((item, idx) => (
                    <div key={idx} className="py-2.5 flex items-start gap-3">
                      <span className="font-mono-tabular text-xs font-medium text-[#1C1917] w-12 shrink-0 pt-0.5">
                        {item.time}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#1C1917]">{item.title}</p>
                        <p className="text-xs text-[#6B655E]">
                          {item.category} · {item.area} · {item.durationMinutes}분
                        </p>
                        <p className="text-xs text-[#4A453F] mt-0.5">{item.note}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setRebalancePreview(null)}
                    className="px-3.5 py-1.5 text-xs font-medium text-[#4A453F] bg-[#FFFFFF] border border-[#D4CBB8] rounded-md cursor-pointer"
                  >
                    유지하기
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onApplyRebalancedDay(day.dayNumber, dayPreview);
                      setRebalancePreview(null);
                    }}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Day {dayCode}에 적용하기</span>
                  </button>
                </div>
              </div>
            )}

            {/* Chronological Hairline Timeline */}
            {day.items.length === 0 ? (
              <div className="py-10 px-6 border border-dashed border-[#D4CBB8] bg-[#F3EFE6]/50 text-center">
                <p className="font-editorial text-base text-[#1C1917]">
                  이 날의 첫 번째 페이지를 채워보세요
                </p>
                <p className="mt-1 text-xs text-[#6B655E]">
                  방문하고 싶은 장소를 직접 추가하거나 AI에게 동선에 맞는 코스를 제안받을 수 있습니다.
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => onAddItem(day.dayNumber)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>직접 일정 추가</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onRequestDayAISuggest(day.dayNumber)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#FFFFFF] text-[#1C1917] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-[#8C4A27]" aria-hidden="true" />
                    <span>AI 장소 추천받기</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="divide-y divide-[#E5DFD3] border-b border-[#E5DFD3]">
                {day.items.map((item: ItineraryItem, index: number) => {
                  const isSelected = selectedItemId === item.id;
                  return (
                    <article
                      key={item.id}
                      onClick={() => onSelectItem(day.dayNumber, item.id)}
                      className={`group py-4 px-3 -mx-3 transition-colors cursor-pointer rounded-md ${
                        isSelected
                          ? "bg-[#F3EFE6]"
                          : "hover:bg-[#F3EFE6]/60"
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleComplete(day.dayNumber, item.id);
                          }}
                          aria-label={
                            item.completed
                              ? `${item.title} 방문 완료 해제`
                              : `${item.title} 방문 완료 표시`
                          }
                          className="mt-0.5 p-1 text-[#6B655E] hover:text-[#1B4332] transition-colors cursor-pointer shrink-0"
                        >
                          {item.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-[#1B4332]" />
                          ) : (
                            <Circle className="w-4 h-4" />
                          )}
                        </button>

                        <div className="w-16 shrink-0 pt-0.5">
                          <p className="font-mono-tabular text-sm font-medium text-[#1C1917]">
                            {item.time}
                          </p>
                          <p className="mt-0.5 font-mono-tabular text-[11px] text-[#6B655E]">
                            {item.durationMinutes}분
                          </p>
                        </div>

                        <div className="flex-1 min-w-0">
                          <h3
                            className={`text-base font-semibold leading-snug ${
                              item.completed
                                ? "line-through text-[#6B655E]"
                                : "text-[#1C1917]"
                            }`}
                          >
                            {item.title}
                          </h3>

                          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-[#6B655E]">
                            <span className="font-medium text-[#8C4A27]">{item.category}</span>
                            <span aria-hidden="true">·</span>
                            <span>{item.area || "지역 미지정"}</span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-tabular">
                              {formatWon(item.estimatedCost)}
                            </span>
                            {item.formattedAddress && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="truncate max-w-[220px]">
                                  {item.formattedAddress}
                                </span>
                              </>
                            )}
                          </div>

                          {item.note && (
                            <p className="mt-2 text-sm text-[#4A453F] leading-relaxed">
                              {item.note}
                            </p>
                          )}

                          {item.transitTip && (
                            <p className="mt-1.5 text-xs text-[#6B655E]">
                              이동 메모: {item.transitTip}
                            </p>
                          )}
                        </div>

                        <div
                          className="flex items-center gap-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 focus-within:opacity-100 transition-opacity shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            disabled={index === 0}
                            onClick={() => onMoveItem(day.dayNumber, item.id, "up")}
                            aria-label="위로 이동"
                            className="p-1.5 text-[#6B655E] hover:text-[#1C1917] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={index === day.items.length - 1}
                            onClick={() => onMoveItem(day.dayNumber, item.id, "down")}
                            aria-label="아래로 이동"
                            className="p-1.5 text-[#6B655E] hover:text-[#1C1917] disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteItem(day.dayNumber, item.id)}
                            aria-label="일정 삭제"
                            className="p-1.5 text-[#6B655E] hover:text-[#B91C1C] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}

            {day.items.length > 0 && (
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onAddItem(day.dayNumber)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1C1917] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Day {dayCode}에 일정 추가</span>
                </button>
                <button
                  type="button"
                  onClick={() => onRequestDayAISuggest(day.dayNumber)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] border border-[#1B4332]/30 rounded-md hover:bg-[#1B4332]/5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>AI로 이 날 코스 보완</span>
                </button>
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
