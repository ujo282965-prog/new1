import { Compass } from "lucide-react";
import { useState } from "react";

interface CoverImageProps {
  src: string;
  alt: string;
  className?: string;
}

export function CoverImage({ src, alt, className = "" }: CoverImageProps) {
  const [hasError, setHasError] = useState(false);

  if (!src || hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#EDE7DA] via-[#E3DBC9] to-[#D4CBB8] text-[#57514A] p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Compass className="w-8 h-8 mb-2 stroke-[1.5]" aria-hidden="true" />
        <p className="font-editorial text-sm tracking-wide text-[#3D3832] max-w-xs text-balance">
          {alt}
        </p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={`object-cover ${className}`}
    />
  );
}
