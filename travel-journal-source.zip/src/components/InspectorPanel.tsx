import { useMapsLibrary } from "@vis.gl/react-google-maps";
import {
  ExternalLink,
  Loader2,
  MapPin,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type {
  ItineraryCategory,
  ItineraryItem,
  LatLngLiteral,
  Trip,
  TripDay,
} from "../types/travel";
import { requestAISpotSuggestions } from "../utils/api";
import { formatWon } from "../utils/storage";

interface InspectorPanelProps {
  trip: Trip;
  mapsEnabled: boolean;
  selectedDayNumber: number;
  selectedItem: ItineraryItem | null;
  aiSuggestTriggerDay: number | null;
  onClearAiTrigger: () => void;
  onClearSelection: () => void;
  onUpdateItem: (
    dayNumber: number,
    itemId: string,
    patch: Partial<ItineraryItem>
  ) => void;
  onMoveItemToDay: (fromDay: number, toDay: number, itemId: string) => void;
  onDeleteItem: (dayNumber: number, itemId: string) => void;
  onInsertSuggestedItem: (
    dayNumber: number,
    item: Omit<ItineraryItem, "id" | "completed">
  ) => void;
}

const CATEGORIES: ItineraryCategory[] = [
  "관광",
  "미식",
  "카페",
  "숙소",
  "이동",
  "쇼핑",
  "휴식",
];

function PlaceAutocompleteFinder({
  destination,
  onSelectPlace,
}: {
  destination: string;
  onSelectPlace: (patch: {
    title: string;
    area: string;
    placeId: string;
    formattedAddress: string;
    location: LatLngLiteral;
  }) => void;
}) {
  const placesLib = useMapsLibrary("places");
  const sessionTokenRef =
    useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<
    google.maps.places.AutocompleteSuggestion[]
  >([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!placesLib || !query.trim()) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        if (!sessionTokenRef.current) {
          sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
        }
        setIsSearching(true);
        const res =
          await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
            input: `${query.trim()} ${destination}`.trim(),
            sessionToken: sessionTokenRef.current,
            language: "ko",
          });
        setSuggestions(res.suggestions ?? []);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (msg.includes("RESOURCE_EXHAUSTED") || msg.includes("OVER_QUERY_LIMIT")) {
          window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
        }
        setSuggestions([]);
      } finally {
        setIsSearching(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [placesLib, query, destination]);

  const handlePick = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    if (!suggestion.placePrediction) return;
    try {
      const place = suggestion.placePrediction.toPlace();
      await place.fetchFields({
        fields: ["id", "displayName", "formattedAddress", "location"],
      });
      const loc = place.location;
      if (loc) {
        onSelectPlace({
          title: place.displayName || suggestion.placePrediction.text.text,
          area: destination,
          placeId: place.id,
          formattedAddress: place.formattedAddress || "",
          location: { lat: loc.lat(), lng: loc.lng() },
        });
      }
      sessionTokenRef.current = null;
      setSuggestions([]);
      setQuery("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes("RESOURCE_EXHAUSTED") || msg.includes("OVER_QUERY_LIMIT")) {
        window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
      }
    }
  };

  if (!placesLib) return null;

  return (
    <div className="space-y-1.5">
      <div className="relative">
        <Search
          className="w-3.5 h-3.5 text-[#6B655E] absolute left-2.5 top-1/2 -translate-y-1/2"
          aria-hidden="true"
        />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Google 지도에서 실제 장소 검색..."
          className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
        />
        {isSearching && (
          <Loader2
            className="w-3.5 h-3.5 animate-spin text-[#6B655E] absolute right-2.5 top-1/2 -translate-y-1/2"
            aria-hidden="true"
          />
        )}
      </div>

      {suggestions.length > 0 && (
        <ul className="bg-[#FFFFFF] border border-[#D4CBB8] divide-y divide-[#E5DFD3] max-h-44 overflow-y-auto">
          {suggestions.slice(0, 5).map((s, idx) => (
            <li key={idx}>
              <button
                type="button"
                onClick={() => handlePick(s)}
                className="w-full text-left px-3 py-2 text-xs hover:bg-[#F3EFE6] transition-colors cursor-pointer flex items-start gap-2"
              >
                <MapPin className="w-3.5 h-3.5 text-[#1B4332] shrink-0 mt-0.5" aria-hidden="true" />
                <span className="text-[#1C1917] leading-snug">
                  {s.placePrediction?.text.text}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function InspectorPanel({
  trip,
  mapsEnabled,
  selectedDayNumber,
  selectedItem,
  aiSuggestTriggerDay,
  onClearAiTrigger,
  onClearSelection,
  onUpdateItem,
  onMoveItemToDay,
  onDeleteItem,
  onInsertSuggestedItem,
}: InspectorPanelProps) {
  const [aiNote, setAiNote] = useState("");
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<
    Array<Omit<ItineraryItem, "id" | "completed">>
  >([]);

  const activeDay: TripDay | undefined =
    trip.days.find((d) => d.dayNumber === (aiSuggestTriggerDay ?? selectedDayNumber)) ??
    trip.days[0];

  const handleFetchSuggestions = async (noteOverride?: string) => {
    if (!activeDay) return;
    setIsLoadingAI(true);
    setAiError(null);
    try {
      const result = await requestAISpotSuggestions({
        destination: trip.destination,
        dayNumber: activeDay.dayNumber,
        dayTitle: activeDay.title,
        existingTitles: activeDay.items.map((i) => i.title),
        companions: trip.companions,
        requestNote: noteOverride ?? aiNote,
      });
      setSuggestions(result.suggestions);
    } catch (err) {
      setAiError(
        err instanceof Error ? err.message : "추천 장소를 불러오지 못했습니다."
      );
    } finally {
      setIsLoadingAI(false);
    }
  };

  useEffect(() => {
    if (aiSuggestTriggerDay !== null) {
      onClearSelection();
      handleFetchSuggestions();
      onClearAiTrigger();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiSuggestTriggerDay]);

  if (selectedItem) {
    const mapQuery = encodeURIComponent(
      `${selectedItem.title} ${selectedItem.area || trip.destination}`
    );

    return (
      <aside className="lg:w-[360px] shrink-0">
        <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-4 lg:sticky lg:top-22">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5DFD3]">
            <div>
              <p className="font-mono-tabular text-[11px] text-[#1B4332]">
                Day {String(selectedDayNumber).padStart(2, "0")} · 일정 편집
              </p>
              <h3 className="mt-0.5 font-editorial text-lg font-semibold text-[#1C1917]">
                세부 마진 노트
              </h3>
            </div>
            <button
              type="button"
              onClick={onClearSelection}
              aria-label="세부 편집 닫기"
              className="p-1.5 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {mapsEnabled && (
            <div>
              <span className="text-[11px] font-medium text-[#6B655E] block mb-1">
                실제 장소 연결 (지도 좌표 자동 반영)
              </span>
              <PlaceAutocompleteFinder
                destination={trip.destination}
                onSelectPlace={(patch) =>
                  onUpdateItem(selectedDayNumber, selectedItem.id, patch)
                }
              />
            </div>
          )}

          <div className="space-y-3.5">
            <label className="block">
              <span className="text-xs font-medium text-[#6B655E]">장소 / 활동명</span>
              <input
                type="text"
                value={selectedItem.title}
                onChange={(e) =>
                  onUpdateItem(selectedDayNumber, selectedItem.id, {
                    title: e.target.value,
                    location: undefined,
                    placeId: undefined,
                  })
                }
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            {selectedItem.formattedAddress && (
              <p className="text-[11px] text-[#1B4332] bg-[#FFFFFF] border border-[#E5DFD3] px-2.5 py-1.5 leading-snug">
                연결된 주소: {selectedItem.formattedAddress}
              </p>
            )}

            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">시작 시각</span>
                <input
                  type="time"
                  value={selectedItem.time}
                  onChange={(e) =>
                    onUpdateItem(selectedDayNumber, selectedItem.id, {
                      time: e.target.value,
                    })
                  }
                  className="mt-1 w-full px-2.5 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">체류 시간 (분)</span>
                <input
                  type="number"
                  min={15}
                  step={15}
                  value={selectedItem.durationMinutes}
                  onChange={(e) =>
                    onUpdateItem(selectedDayNumber, selectedItem.id, {
                      durationMinutes: Math.max(15, Number(e.target.value) || 30),
                    })
                  }
                  className="mt-1 w-full px-2.5 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
                />
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">카테고리</span>
                <select
                  value={selectedItem.category}
                  onChange={(e) =>
                    onUpdateItem(selectedDayNumber, selectedItem.id, {
                      category: e.target.value as ItineraryCategory,
                    })
                  }
                  className="mt-1 w-full px-2.5 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">예상 비용 (원)</span>
                <input
                  type="number"
                  min={0}
                  step={1000}
                  value={selectedItem.estimatedCost}
                  onChange={(e) =>
                    onUpdateItem(selectedDayNumber, selectedItem.id, {
                      estimatedCost: Math.max(0, Number(e.target.value) || 0),
                    })
                  }
                  className="mt-1 w-full px-2.5 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
                />
              </label>
            </div>

            <label className="block">
              <span className="text-xs font-medium text-[#6B655E]">세부 권역 / 동네</span>
              <input
                type="text"
                value={selectedItem.area}
                onChange={(e) =>
                  onUpdateItem(selectedDayNumber, selectedItem.id, {
                    area: e.target.value,
                  })
                }
                placeholder="예: 히가시야마, 성수동"
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-[#6B655E]">저널 메모 & 방문 팁</span>
              <textarea
                rows={3}
                value={selectedItem.note}
                onChange={(e) =>
                  onUpdateItem(selectedDayNumber, selectedItem.id, {
                    note: e.target.value,
                  })
                }
                placeholder="추천 메뉴, 예약 여부, 분위기 메모"
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            <label className="block">
              <span className="text-xs font-medium text-[#6B655E]">이동 방법 메모</span>
              <input
                type="text"
                value={selectedItem.transitTip}
                onChange={(e) =>
                  onUpdateItem(selectedDayNumber, selectedItem.id, {
                    transitTip: e.target.value,
                  })
                }
                placeholder="예: 지하철역에서 도보 8분"
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            {trip.days.length > 1 && (
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">다른 일차로 이동</span>
                <select
                  value={selectedDayNumber}
                  onChange={(e) =>
                    onMoveItemToDay(
                      selectedDayNumber,
                      Number(e.target.value),
                      selectedItem.id
                    )
                  }
                  className="mt-1 w-full px-2.5 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                >
                  {trip.days.map((d) => (
                    <option key={d.dayNumber} value={d.dayNumber}>
                      Day {String(d.dayNumber).padStart(2, "0")} — {d.title}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>

          <div className="pt-3 border-t border-[#E5DFD3] flex items-center justify-between gap-2">
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${mapQuery}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs font-medium text-[#1B4332] hover:underline"
            >
              <span>Google 지도 열기</span>
              <ExternalLink className="w-3 h-3" aria-hidden="true" />
            </a>
            <button
              type="button"
              onClick={() => onDeleteItem(selectedDayNumber, selectedItem.id)}
              className="inline-flex items-center gap-1 text-xs font-medium text-[#B91C1C] hover:underline cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
              <span>일정 삭제</span>
            </button>
          </div>
        </div>
      </aside>
    );
  }

  const dayDurationTotal = (activeDay?.items ?? []).reduce(
    (sum, i) => sum + (i.durationMinutes || 0),
    0
  );
  const dayBudgetTotal = (activeDay?.items ?? []).reduce(
    (sum, i) => sum + (i.estimatedCost || 0),
    0
  );
  const dayMappedCount = (activeDay?.items ?? []).filter((i) =>
    Boolean(i.location)
  ).length;

  return (
    <aside className="lg:w-[360px] shrink-0 space-y-4 lg:sticky lg:top-22">
      {activeDay && (
        <div className="bg-[#FFFFFF] border border-[#E5DFD3] p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-mono-tabular text-[11px] font-medium text-[#1B4332]">
              DAY {String(activeDay.dayNumber).padStart(2, "0")} 브리핑
            </span>
            <span className="font-mono-tabular text-[11px] text-[#6B655E]">
              {activeDay.items.length}개 장소
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 pt-1 border-t border-[#E5DFD3]">
            <div>
              <p className="text-[11px] text-[#6B655E]">총 체류</p>
              <p className="font-mono-tabular text-xs font-semibold text-[#1C1917] mt-0.5">
                {Math.floor(dayDurationTotal / 60)}시간 {dayDurationTotal % 60}분
              </p>
            </div>
            <div>
              <p className="text-[11px] text-[#6B655E]">예상 경비</p>
              <p className="font-mono-tabular text-xs font-semibold text-[#1C1917] mt-0.5">
                {formatWon(dayBudgetTotal)}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-[#6B655E]">지도 연결</p>
              <p className="font-mono-tabular text-xs font-semibold text-[#1B4332] mt-0.5">
                {dayMappedCount}/{activeDay.items.length}곳
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-4">
        <div className="pb-3 border-b border-[#E5DFD3]">
          <p className="font-mono-tabular text-[11px] text-[#1B4332]">
            {activeDay ? `Day ${String(activeDay.dayNumber).padStart(2, "0")} 큐레이션` : "AI 큐레이터"}
          </p>
          <h3 className="mt-0.5 font-editorial text-lg font-semibold text-[#1C1917]">
            AI 일자별 장소 제안
          </h3>
          <p className="mt-1 text-xs leading-relaxed text-[#6B655E]">
            특정 시간대나 분위기에 맞는 장소를 물어보면 현재 동선과 겹치지 않는 3곳을 제안해 드립니다.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleFetchSuggestions();
          }}
          className="space-y-2.5"
        >
          <textarea
            rows={2}
            value={aiNote}
            onChange={(e) => setAiNote(e.target.value)}
            placeholder="예: 오후 3시쯤 가기 좋은 조용한 찻집이나 실내 미술관"
            className="w-full px-3 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
          />
          <button
            type="submit"
            disabled={isLoadingAI || !activeDay}
            className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] disabled:opacity-60 transition-colors cursor-pointer"
          >
            {isLoadingAI ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                <span>동선 분석 중...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Day {activeDay?.dayNumber ?? 1} 추천 장소 3곳 받기</span>
              </>
            )}
          </button>
        </form>

        {aiError && (
          <div className="p-3 bg-[#FFFFFF] border border-[#B91C1C]/30 text-xs text-[#B91C1C] leading-relaxed">
            {aiError}
          </div>
        )}

        {isLoadingAI && (
          <div className="space-y-3 pt-2">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="p-3 bg-[#FFFFFF] border border-[#E5DFD3] animate-pulse space-y-2"
              >
                <div className="h-3 w-20 bg-[#E5DFD3]" />
                <div className="h-4 w-3/4 bg-[#E5DFD3]" />
                <div className="h-3 w-full bg-[#F3EFE6]" />
              </div>
            ))}
          </div>
        )}

        {!isLoadingAI && suggestions.length > 0 && activeDay && (
          <div className="space-y-3 pt-1">
            {suggestions.map((spot, idx) => (
              <div
                key={`${spot.title}-${idx}`}
                className="p-3.5 bg-[#FFFFFF] border border-[#E5DFD3] space-y-2"
              >
                <div className="flex items-center justify-between gap-2 text-[11px] text-[#6B655E]">
                  <span className="font-mono-tabular text-[#1C1917] font-medium">
                    {spot.time} · {spot.durationMinutes}분
                  </span>
                  <span>{spot.category} · {formatWon(spot.estimatedCost)}</span>
                </div>
                <h4 className="text-sm font-semibold text-[#1C1917]">{spot.title}</h4>
                <p className="text-xs text-[#6B655E]">{spot.area}</p>
                <p className="text-xs text-[#4A453F] leading-relaxed">{spot.note}</p>
                <button
                  type="button"
                  onClick={() => onInsertSuggestedItem(activeDay.dayNumber, spot)}
                  className="w-full mt-1 inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-[#1B4332] border border-[#1B4332]/40 rounded-md hover:bg-[#1B4332] hover:text-[#FBF9F5] transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Day {activeDay.dayNumber} 일정에 추가</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}
