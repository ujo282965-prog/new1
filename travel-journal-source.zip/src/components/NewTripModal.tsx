import { Sparkles, X } from "lucide-react";
import { useState } from "react";
import { COVER_PRESETS } from "../data/seedTrips";
import type { CompanionType, PaceType } from "../types/travel";
import { CoverImage } from "./CoverImage";

interface NewTripModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateBlankTrip: (payload: {
    title: string;
    destination: string;
    startDate: string;
    endDate: string;
    daysCount: number;
    companions: CompanionType;
    pace: PaceType;
    journalNote: string;
    coverImage: string;
    coverCaption: string;
  }) => void;
  onSwitchToAI: () => void;
}

const COMPANION_OPTIONS: CompanionType[] = ["혼자", "친구", "가족", "연인"];
const PACE_OPTIONS: PaceType[] = ["여유롭게", "균형 있게", "알차게"];

export function NewTripModal({
  isOpen,
  onClose,
  onCreateBlankTrip,
  onSwitchToAI,
}: NewTripModalProps) {
  const [title, setTitle] = useState("");
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("2026-12-12");
  const [endDate, setEndDate] = useState("2026-12-14");
  const [daysCount, setDaysCount] = useState(3);
  const [companions, setCompanions] = useState<CompanionType>("친구");
  const [pace, setPace] = useState<PaceType>("균형 있게");
  const [journalNote, setJournalNote] = useState("");
  const [coverIdx, setCoverIdx] = useState(1);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const chosen = COVER_PRESETS[coverIdx] ?? COVER_PRESETS[0];
    const cleanDest = destination.trim() || "새로운 목적지";
    onCreateBlankTrip({
      title: title.trim() || `${cleanDest}의 기록`,
      destination: cleanDest,
      startDate,
      endDate,
      daysCount,
      companions,
      pace,
      journalNote: journalNote.trim(),
      coverImage: chosen.image,
      coverCaption: chosen.caption,
    });
    setTitle("");
    setDestination("");
    setJournalNote("");
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1C1917]/50 backdrop-blur-[2px] flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="new-trip-title"
    >
      <div className="w-full max-w-2xl bg-[#FBF9F5] border border-[#D4CBB8] shadow-xl">
        <div className="px-6 py-4 border-b border-[#E5DFD3] flex items-center justify-between">
          <div>
            <p className="font-mono-tabular text-[11px] text-[#1B4332]">
              NEW TRAVEL JOURNAL
            </p>
            <h2
              id="new-trip-title"
              className="font-editorial text-xl font-semibold text-[#1C1917]"
            >
              새 여행 저널 시작하기
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="p-2 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-4 bg-[#F3EFE6] border border-[#E5DFD3] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-[#1C1917]">
                일정 초안을 빠르게 받고 싶으신가요?
              </p>
              <p className="text-xs text-[#6B655E]">
                목적지와 취향만 입력하면 AI가 일자별 타임라인을 먼저 구성해 드립니다.
              </p>
            </div>
            <button
              type="button"
              onClick={onSwitchToAI}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1B4332] bg-[#FFFFFF] border border-[#1B4332]/40 rounded-md hover:bg-[#1B4332] hover:text-[#FBF9F5] transition-colors shrink-0 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
              <span>AI 코스 추천으로 시작</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">여행지</span>
              <input
                type="text"
                required
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="예: 서울 북촌, 리스본, 도쿄"
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">저널 제목</span>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="예: 겨울 빛이 머무는 사흘"
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">여행 일수</span>
              <select
                value={daysCount}
                onChange={(e) => setDaysCount(Number(e.target.value))}
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
              >
                {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                  <option key={n} value={n}>
                    {n === 1 ? "당일치기 (1일)" : `${n - 1}박 ${n}일`}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">출발일</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
              />
            </label>
            <label className="block">
              <span className="text-xs font-semibold text-[#1C1917]">도착일</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md font-mono-tabular focus:outline-none focus:border-[#1B4332]"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <span className="text-xs font-semibold text-[#1C1917]">동행 구성</span>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {COMPANION_OPTIONS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCompanions(c)}
                    className={`px-3 py-1.5 text-xs rounded-md border cursor-pointer ${
                      companions === c
                        ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                        : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8]"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <span className="text-xs font-semibold text-[#1C1917]">여행 페이스</span>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {PACE_OPTIONS.map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPace(p)}
                    className={`px-3 py-1.5 text-xs rounded-md border cursor-pointer ${
                      pace === p
                        ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                        : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8]"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold text-[#1C1917]">저널 표지 선택</span>
            <div className="mt-1.5 grid grid-cols-4 gap-2.5">
              {COVER_PRESETS.map((preset, idx) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setCoverIdx(idx)}
                  className={`border p-1 bg-[#FFFFFF] text-left cursor-pointer ${
                    coverIdx === idx
                      ? "border-[#1B4332] ring-1 ring-[#1B4332]"
                      : "border-[#E5DFD3]"
                  }`}
                >
                  <div className="aspect-[16/10] overflow-hidden">
                    <CoverImage
                      src={preset.image}
                      alt={preset.label}
                      className="w-full h-full"
                    />
                  </div>
                  <p className="mt-1 text-[11px] text-[#4A453F] truncate">
                    {preset.label}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="text-xs font-semibold text-[#1C1917]">여정 메모 (선택)</span>
            <textarea
              rows={2}
              value={journalNote}
              onChange={(e) => setJournalNote(e.target.value)}
              placeholder="이번 여행에서 꼭 담아오고 싶은 분위기나 약속을 적어두세요."
              className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
            />
          </label>

          <div className="pt-3 border-t border-[#E5DFD3] flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#4A453F] border border-[#D4CBB8] bg-[#FFFFFF] rounded-md hover:bg-[#F3EFE6] cursor-pointer"
            >
              취소
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
            >
              빈 저널 만들기
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
