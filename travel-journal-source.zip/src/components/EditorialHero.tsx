import { Check, Link2, MapPinned, Pencil, Sparkles, X } from "lucide-react";
import { useState } from "react";
import { COVER_PRESETS } from "../data/seedTrips";
import type { CompanionType, PaceType, Trip } from "../types/travel";
import { encodeTripToShareHash } from "../utils/share";
import { calculateNightsAndDays, formatDateRange, formatWon } from "../utils/storage";
import { CoverImage } from "./CoverImage";

interface EditorialHeroProps {
  trip: Trip;
  onUpdateTripMeta: (patch: Partial<Trip>) => void;
  onOpenAIPlanner: () => void;
  onOpenMapView: () => void;
}

const COMPANION_OPTIONS: CompanionType[] = ["혼자", "친구", "가족", "연인"];
const PACE_OPTIONS: PaceType[] = ["여유롭게", "균형 있게", "알차게"];

export function EditorialHero({
  trip,
  onUpdateTripMeta,
  onOpenAIPlanner,
  onOpenMapView,
}: EditorialHeroProps) {
  const [isEditingMeta, setIsEditingMeta] = useState(false);
  const [copiedNotice, setCopiedNotice] = useState(false);

  const [title, setTitle] = useState(trip.title);
  const [destination, setDestination] = useState(trip.destination);
  const [startDate, setStartDate] = useState(trip.startDate);
  const [endDate, setEndDate] = useState(trip.endDate);
  const [companions, setCompanions] = useState<CompanionType>(trip.companions);
  const [pace, setPace] = useState<PaceType>(trip.pace);
  const [journalNote, setJournalNote] = useState(trip.journalNote);
  const [coverImage, setCoverImage] = useState(trip.coverImage);

  const openEditor = () => {
    setTitle(trip.title);
    setDestination(trip.destination);
    setStartDate(trip.startDate);
    setEndDate(trip.endDate);
    setCompanions(trip.companions);
    setPace(trip.pace);
    setJournalNote(trip.journalNote);
    setCoverImage(trip.coverImage);
    setIsEditingMeta(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const matchedPreset = COVER_PRESETS.find((p) => p.image === coverImage);
    onUpdateTripMeta({
      title: title.trim() || trip.title,
      destination: destination.trim() || trip.destination,
      startDate,
      endDate,
      companions,
      pace,
      journalNote: journalNote.trim(),
      coverImage,
      coverCaption: matchedPreset ? matchedPreset.caption : trip.coverCaption,
    });
    setIsEditingMeta(false);
  };

  const handleCopyShareLink = async () => {
    try {
      const hash = encodeTripToShareHash(trip);
      const url = `${window.location.origin}${window.location.pathname}${hash}`;
      await navigator.clipboard.writeText(url);
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 2800);
    } catch {
      // Fallback if clipboard API unavailable
      const hash = encodeTripToShareHash(trip);
      window.location.hash = hash;
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 2800);
    }
  };

  const allItems = trip.days.flatMap((d) => d.items);
  const completedCount = allItems.filter((i) => i.completed).length;
  const totalPlannedCost = allItems.reduce((sum, i) => sum + (i.estimatedCost || 0), 0);
  const actualExpenseSum = (trip.expenses ?? []).reduce((sum, e) => sum + e.amount, 0);
  const packingCount = (trip.packingList ?? []).length;
  const packedCount = (trip.packingList ?? []).filter((p) => p.checked).length;

  return (
    <section className="border-b border-[#E5DFD3] bg-[#FBF9F5]">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-7">
        {!isEditingMeta ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
            <div className="lg:col-span-5 flex flex-col">
              <div className="aspect-[16/10] lg:aspect-auto lg:h-full min-h-[220px] max-h-[290px] overflow-hidden border border-[#E5DFD3] bg-[#F3EFE6]">
                <CoverImage
                  src={trip.coverImage}
                  alt={trip.title}
                  className="w-full h-full"
                />
              </div>
              <p className="mt-2 text-xs font-editorial italic text-[#6B655E]">
                {trip.coverCaption || `Fig. — ${trip.destination}`}
              </p>
            </div>

            <div className="lg:col-span-7 flex flex-col justify-between py-1">
              <div>
                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs tracking-wide text-[#6B655E]">
                  <span className="font-medium text-[#1B4332]">{trip.destination}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">
                    {formatDateRange(trip.startDate, trip.endDate)}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{calculateNightsAndDays(trip.startDate, trip.endDate, trip.days.length)}</span>
                  <span aria-hidden="true">·</span>
                  <span>{trip.companions}와 함께</span>
                  <span aria-hidden="true">·</span>
                  <span>{trip.pace}</span>
                </div>

                <h1 className="mt-3 font-editorial text-3xl lg:text-4xl font-semibold text-[#1C1917] leading-tight text-balance">
                  {trip.title}
                </h1>

                <p className="mt-4 text-sm lg:text-[15px] leading-relaxed text-[#4A453F] max-w-2xl">
                  {trip.journalNote ||
                    "이 여정의 서문을 작성해 보세요. 동행과 나누고 싶은 분위기나 핵심 테마를 짧게 기록할 수 있습니다."}
                </p>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-2.5 pt-4 border-t border-[#E5DFD3]">
                <button
                  type="button"
                  onClick={openEditor}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1C1917] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>여행 정보 수정</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenAIPlanner}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] border border-[#1B4332]/35 rounded-md hover:bg-[#1B4332]/5 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>AI 코스 설계</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenMapView}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1C1917] border border-[#D4CBB8] rounded-md hover:bg-[#F3EFE6] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <MapPinned className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>지도 동선 보기</span>
                </button>
                <button
                  type="button"
                  onClick={handleCopyShareLink}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#8C4A27] border border-[#8C4A27]/35 rounded-md hover:bg-[#8C4A27]/5 transition-colors cursor-pointer whitespace-nowrap"
                >
                  {copiedNotice ? (
                    <>
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>공유 링크 복사됨</span>
                    </>
                  ) : (
                    <>
                      <Link2 className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>링크로 공유</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSave}
            className="bg-[#F3EFE6] border border-[#E5DFD3] p-6 space-y-5"
          >
            <div className="flex items-center justify-between border-b border-[#E5DFD3] pb-3">
              <h2 className="font-editorial text-lg font-semibold text-[#1C1917]">
                여행 저널 기본 정보 편집
              </h2>
              <button
                type="button"
                onClick={() => setIsEditingMeta(false)}
                className="p-1.5 text-[#6B655E] hover:text-[#1C1917] cursor-pointer"
                aria-label="편집 닫기"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <label className="block lg:col-span-2">
                <span className="text-xs font-medium text-[#6B655E]">저널 제목</span>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                />
              </label>
              <label className="block">
                <span className="text-xs font-medium text-[#6B655E]">여행지</span>
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  required
                  className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
                />
              </label>
              <div className="grid grid-cols-2 gap-2">
                <label className="block">
                  <span className="text-xs font-medium text-[#6B655E]">출발일</span>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="mt-1 w-full px-2.5 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332] tabular-nums"
                  />
                </label>
                <label className="block">
                  <span className="text-xs font-medium text-[#6B655E]">도착일</span>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="mt-1 w-full px-2.5 py-2 text-xs bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332] tabular-nums"
                  />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-xs font-medium text-[#6B655E]">동행 구성</span>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {COMPANION_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setCompanions(opt)}
                      className={`px-3 py-1.5 text-xs rounded-md border transition-colors cursor-pointer ${
                        companions === opt
                          ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                          : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8] hover:border-[#1C1917]"
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-xs font-medium text-[#6B655E]">여행 페이스</span>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {PACE_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setPace(opt)}
                      className={`px-3 py-1.5 text-xs rounded-md border transition-colors cursor-pointer ${
                        pace === opt
                          ? "bg-[#1B4332] text-[#FBF9F5] border-[#1B4332]"
                          : "bg-[#FFFFFF] text-[#4A453F] border-[#D4CBB8] hover:border-[#1C1917]"
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <span className="text-xs font-medium text-[#6B655E]">커버 사진 선택</span>
              <div className="mt-1.5 grid grid-cols-2 sm:grid-cols-4 gap-3">
                {COVER_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setCoverImage(preset.image)}
                    className={`text-left border p-1.5 bg-[#FFFFFF] transition-colors cursor-pointer ${
                      coverImage === preset.image
                        ? "border-[#1B4332] ring-1 ring-[#1B4332]"
                        : "border-[#E5DFD3] hover:border-[#6B655E]"
                    }`}
                  >
                    <div className="aspect-[16/9] overflow-hidden">
                      <CoverImage
                        src={preset.image}
                        alt={preset.label}
                        className="w-full h-full"
                      />
                    </div>
                    <p className="mt-1.5 text-[11px] font-medium text-[#1C1917] truncate">
                      {preset.label}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            <label className="block">
              <span className="text-xs font-medium text-[#6B655E]">저널 서문 (여정 메모)</span>
              <textarea
                rows={2}
                value={journalNote}
                onChange={(e) => setJournalNote(e.target.value)}
                className="mt-1 w-full px-3 py-2 text-sm bg-[#FFFFFF] border border-[#D4CBB8] rounded-md focus:outline-none focus:border-[#1B4332]"
              />
            </label>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingMeta(false)}
                className="px-4 py-2 text-xs font-medium text-[#4A453F] border border-[#D4CBB8] bg-[#FFFFFF] rounded-md hover:bg-[#FBF9F5] cursor-pointer"
              >
                취소
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
              >
                <Check className="w-3.5 h-3.5" aria-hidden="true" />
                <span>변경사항 저장</span>
              </button>
            </div>
          </form>
        )}

        {/* Full-width 4-column editorial summary strip */}
        <div className="mt-6 pt-5 border-t border-[#E5DFD3] grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          <div className="bg-[#F3EFE6]/60 border border-[#E5DFD3] px-4 py-3">
            <p className="text-xs text-[#6B655E]">전체 일정</p>
            <p className="mt-1 font-mono-tabular text-lg font-medium text-[#1C1917]">
              {allItems.length}개 장소 · {trip.days.length}일
            </p>
            <p className="mt-0.5 font-mono-tabular text-[11px] text-[#6B655E]">
              하루 평균 {trip.days.length > 0 ? (allItems.length / trip.days.length).toFixed(1) : 0}곳 방문
            </p>
          </div>
          <div className="bg-[#F3EFE6]/60 border border-[#E5DFD3] px-4 py-3">
            <p className="text-xs text-[#6B655E]">방문 체크 · 예약</p>
            <p className="mt-1 font-mono-tabular text-lg font-medium text-[#1C1917]">
              {completedCount} / {allItems.length} 완료
            </p>
            <p className="mt-0.5 font-mono-tabular text-[11px] text-[#6B655E]">
              확정 예약 {(trip.reservations ?? []).length}건 등록됨
            </p>
          </div>
          <div className="bg-[#F3EFE6]/60 border border-[#E5DFD3] px-4 py-3">
            <p className="text-xs text-[#6B655E]">지출 / 1인 예상</p>
            <p className="mt-1 font-mono-tabular text-lg font-medium text-[#1C1917]">
              {actualExpenseSum > 0 ? formatWon(actualExpenseSum) : formatWon(totalPlannedCost)}
            </p>
            <p className="mt-0.5 font-mono-tabular text-[11px] text-[#6B655E]">
              {actualExpenseSum > 0
                ? `일정 예상 ${formatWon(totalPlannedCost)}`
                : `${(trip.travelers ?? ["나"]).length}명 기준 경비`}
            </p>
          </div>
          <div className="bg-[#F3EFE6]/60 border border-[#E5DFD3] px-4 py-3">
            <p className="text-xs text-[#6B655E]">준비물 체크</p>
            <p className="mt-1 font-mono-tabular text-lg font-medium text-[#1C1917]">
              {packedCount} / {packingCount} 완료
            </p>
            <p className="mt-0.5 font-mono-tabular text-[11px] text-[#6B655E]">
              {packingCount > 0
                ? `준비율 ${Math.round((packedCount / packingCount) * 100)}%`
                : "체크리스트를 채워보세요"}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
