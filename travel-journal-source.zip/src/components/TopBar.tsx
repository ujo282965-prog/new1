import type { AppViewMode } from "../types/travel";

interface TopBarProps {
  viewMode: AppViewMode;
  onSelectView: (mode: AppViewMode) => void;
  onOpenNewTrip: () => void;
}

const NAV_ITEMS: Array<{ id: AppViewMode; label: string }> = [
  { id: "editor", label: "일정 편집" },
  { id: "map", label: "지도 동선" },
  { id: "appendix", label: "경비·부록" },
  { id: "magazine", label: "매거진 보기" },
  { id: "library", label: "내 여행 서가" },
];

export function TopBar({
  viewMode,
  onSelectView,
  onOpenNewTrip,
}: TopBarProps) {
  return (
    <header className="no-print border-b border-[#E5DFD3] bg-[#FBF9F5]/95 backdrop-blur-sm sticky top-0 z-30">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={() => onSelectView("editor")}
          className="font-editorial text-xl font-semibold tracking-tight text-[#1C1917] whitespace-nowrap shrink-0 hover:opacity-80 transition-opacity cursor-pointer"
        >
          여백의 여정
        </button>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="주요 메뉴"
          className="hidden md:flex items-center gap-6 lg:gap-7 text-sm font-medium"
        >
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectView(item.id)}
              className={`py-1 whitespace-nowrap shrink-0 border-b transition-colors cursor-pointer ${
                viewMode === item.id
                  ? "text-[#1C1917] border-[#1B4332]"
                  : "text-[#6B655E] border-transparent hover:text-[#1C1917]"
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="shrink-0">
          <button
            type="button"
            onClick={onOpenNewTrip}
            className="px-4 py-2 text-xs sm:text-sm font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            새 여행 만들기
          </button>
        </div>
      </div>

      {/* Compact mobile navigation row */}
      <nav
        aria-label="모바일 메뉴"
        className="md:hidden flex items-center justify-between gap-3 px-6 py-2 border-t border-[#E5DFD3] text-xs font-medium overflow-x-auto"
      >
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => onSelectView(item.id)}
            className={`whitespace-nowrap shrink-0 py-1 ${
              viewMode === item.id
                ? "text-[#1B4332] font-semibold"
                : "text-[#6B655E]"
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>
    </header>
  );
}
