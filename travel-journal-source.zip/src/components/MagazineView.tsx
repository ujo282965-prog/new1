import { ArrowLeft, Check, Link2, Printer } from "lucide-react";
import { useState } from "react";
import type { Trip } from "../types/travel";
import { encodeTripToShareHash } from "../utils/share";
import { calculateNightsAndDays, formatDateRange, formatWon } from "../utils/storage";
import { CoverImage } from "./CoverImage";

interface MagazineViewProps {
  trip: Trip;
  onBackToEditor: () => void;
}

export function MagazineView({ trip, onBackToEditor }: MagazineViewProps) {
  const [copied, setCopied] = useState(false);

  const allItems = trip.days.flatMap((d) => d.items);
  const totalCost = allItems.reduce((sum, i) => sum + (i.estimatedCost || 0), 0);
  const reservations = trip.reservations ?? [];
  const expenses = trip.expenses ?? [];
  const packingList = trip.packingList ?? [];
  const totalSpent = expenses.reduce((s, e) => s + e.amount, 0);

  const handleShare = async () => {
    const hash = encodeTripToShareHash(trip);
    const url = `${window.location.origin}${window.location.pathname}${hash}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      window.location.hash = hash;
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <main className="max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8 space-y-8">
      {/* Utility action bar (hidden when printing) */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#E5DFD3]">
        <button
          type="button"
          onClick={onBackToEditor}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-[#4A453F] hover:text-[#1C1917] cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          <span>편집 화면으로 돌아가기</span>
        </button>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#1C1917] border border-[#D4CBB8] bg-[#FFFFFF] rounded-md hover:bg-[#F3EFE6] cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#1B4332]" aria-hidden="true" />
                <span>링크 복사됨</span>
              </>
            ) : (
              <>
                <Link2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>공유 링크 복사</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium bg-[#1B4332] text-[#FBF9F5] rounded-md hover:bg-[#143326] cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" aria-hidden="true" />
            <span>매거진 인쇄 / PDF 저장</span>
          </button>
        </div>
      </div>

      {/* Editorial 2-Column Spread */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
        {/* Left 8 Columns: Narrative & Day Chapters */}
        <div className="lg:col-span-8 space-y-10">
          <header className="space-y-4">
            <p className="font-mono-tabular text-xs tracking-widest text-[#6B655E]">
              TRAVEL MONOGRAPH · {trip.destination} · {formatDateRange(trip.startDate, trip.endDate)}
            </p>

            <h1 className="font-editorial text-4xl lg:text-5xl font-semibold text-[#1C1917] leading-tight text-balance">
              {trip.title}
            </h1>

            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-[#6B655E] pt-1">
              <span>{calculateNightsAndDays(trip.startDate, trip.endDate, trip.days.length)}</span>
              <span aria-hidden="true">·</span>
              <span>{trip.companions}와 함께</span>
              <span aria-hidden="true">·</span>
              <span>{trip.pace}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">총 {allItems.length}개 장소</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular">
                {totalSpent > 0
                  ? `총 지출 ${formatWon(totalSpent)}`
                  : `1인 예상 ${formatWon(totalCost)}`}
              </span>
            </div>
          </header>

          {/* Drop-cap Foreword */}
          {trip.journalNote && (
            <section className="border-y border-[#E5DFD3] py-6">
              <p className="text-base leading-loose text-[#292524] max-w-3xl first-letter:text-5xl first-letter:font-editorial first-letter:font-semibold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:leading-none">
                {trip.journalNote}
              </p>
            </section>
          )}

          {/* Day Chapters */}
          <div className="space-y-12">
            {trip.days.map((day) => (
              <section
                id={`mag-day-${day.dayNumber}`}
                key={day.dayNumber}
                className="space-y-5 print-break-inside-avoid"
              >
                <div className="border-b border-[#1C1917] pb-3 flex items-baseline justify-between gap-4">
                  <div>
                    <p className="font-mono-tabular text-xs font-medium text-[#1B4332]">
                      CHAPTER {String(day.dayNumber).padStart(2, "0")}
                    </p>
                    <h2 className="mt-1 font-editorial text-2xl font-semibold text-[#1C1917] text-balance">
                      {day.title}
                    </h2>
                  </div>
                  <span className="font-mono-tabular text-xs text-[#6B655E] shrink-0">
                    {day.items.length} STOPS
                  </span>
                </div>

                {day.summary && (
                  <blockquote className="py-2 font-editorial italic text-lg text-[#4A453F] border-b border-[#E5DFD3]">
                    “{day.summary}”
                  </blockquote>
                )}

                {day.items.length === 0 ? (
                  <p className="text-sm text-[#6B655E] italic">
                    이 날에 기록된 일정이 아직 없습니다.
                  </p>
                ) : (
                  <div className="divide-y divide-[#E5DFD3]">
                    {day.items.map((item) => (
                      <div
                        key={item.id}
                        className="py-4 grid grid-cols-1 sm:grid-cols-12 gap-3 sm:gap-6"
                      >
                        <div className="sm:col-span-3">
                          <p className="font-mono-tabular text-sm font-medium text-[#1C1917]">
                            {item.time}
                          </p>
                          <p className="mt-0.5 text-xs text-[#6B655E]">
                            {item.category} · {item.durationMinutes}분
                          </p>
                        </div>
                        <div className="sm:col-span-9 space-y-1.5">
                          <div className="flex items-baseline justify-between gap-4">
                            <h3 className="text-base font-semibold text-[#1C1917]">
                              {item.title}
                            </h3>
                            <span className="font-mono-tabular text-xs text-[#6B655E] shrink-0">
                              {formatWon(item.estimatedCost)}
                            </span>
                          </div>
                          <p className="text-xs text-[#8C4A27]">{item.area}</p>
                          {item.note && (
                            <p className="text-sm leading-relaxed text-[#4A453F]">
                              {item.note}
                            </p>
                          )}
                          {item.transitTip && (
                            <p className="text-xs text-[#6B655E]">
                              이동: {item.transitTip}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            ))}
          </div>

          {/* Reservations Appendix in Monograph */}
          {reservations.length > 0 && (
            <section className="pt-8 border-t border-[#1C1917] space-y-4 print-break-inside-avoid">
              <p className="font-mono-tabular text-xs text-[#1B4332]">
                APPENDIX · RESERVATIONS
              </p>
              <h2 className="font-editorial text-2xl font-semibold text-[#1C1917]">
                예약 및 바우처 메모
              </h2>
              <div className="divide-y divide-[#E5DFD3]">
                {reservations.map((res) => (
                  <div
                    key={res.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <p className="text-xs text-[#8C4A27]">
                        {res.type} {res.dateTime ? `· ${res.dateTime}` : ""}
                      </p>
                      <p className="text-sm font-semibold text-[#1C1917]">{res.title}</p>
                      {res.location && (
                        <p className="text-xs text-[#6B655E]">{res.location}</p>
                      )}
                    </div>
                    {res.confirmationCode && (
                      <p className="font-mono-tabular text-xs font-medium text-[#1B4332]">
                        예약코드: {res.confirmationCode}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Right 4 Columns: Archival Cover & Margin Dossier */}
        <aside className="lg:col-span-4 space-y-6 lg:sticky lg:top-22">
          <figure>
            <div className="aspect-[4/3] overflow-hidden border border-[#E5DFD3] bg-[#F3EFE6]">
              <CoverImage
                src={trip.coverImage}
                alt={trip.title}
                className="w-full h-full"
              />
            </div>
            <figcaption className="mt-2.5 text-xs font-editorial italic text-[#6B655E]">
              {trip.coverCaption || `Fig. — ${trip.destination}`}
            </figcaption>
          </figure>

          <div className="bg-[#F3EFE6] border border-[#E5DFD3] p-5 space-y-4">
            <p className="font-mono-tabular text-[11px] font-medium text-[#1B4332]">
              MONOGRAPH DOSSIER
            </p>
            <dl className="divide-y divide-[#E5DFD3] text-xs">
              <div className="py-2 flex justify-between gap-3">
                <dt className="text-[#6B655E]">목적지</dt>
                <dd className="font-medium text-[#1C1917]">{trip.destination}</dd>
              </div>
              <div className="py-2 flex justify-between gap-3">
                <dt className="text-[#6B655E]">동행 구성</dt>
                <dd className="font-medium text-[#1C1917]">
                  {(trip.travelers ?? ["나"]).join(", ")}
                </dd>
              </div>
              <div className="py-2 flex justify-between gap-3">
                <dt className="text-[#6B655E]">일정 예상 경비</dt>
                <dd className="font-mono-tabular font-medium text-[#1C1917]">
                  {formatWon(totalCost)}
                </dd>
              </div>
              <div className="py-2 flex justify-between gap-3">
                <dt className="text-[#6B655E]">실제 기록 지출</dt>
                <dd className="font-mono-tabular font-medium text-[#1B4332]">
                  {formatWon(totalSpent)}
                </dd>
              </div>
              <div className="py-2 flex justify-between gap-3">
                <dt className="text-[#6B655E]">준비물 체크</dt>
                <dd className="font-mono-tabular font-medium text-[#1C1917]">
                  {packingList.filter((p) => p.checked).length} / {packingList.length}
                </dd>
              </div>
            </dl>
          </div>

          <div className="no-print border border-[#E5DFD3] bg-[#FFFFFF] p-5 space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#6B655E]">
              CHAPTER INDEX
            </p>
            <ul className="divide-y divide-[#E5DFD3]">
              {trip.days.map((d) => (
                <li key={d.dayNumber}>
                  <a
                    href={`#mag-day-${d.dayNumber}`}
                    className="py-2 flex items-center justify-between gap-2 text-xs hover:text-[#1B4332] transition-colors"
                  >
                    <span className="truncate font-medium text-[#1C1917]">
                      {String(d.dayNumber).padStart(2, "0")}. {d.title}
                    </span>
                    <span className="font-mono-tabular text-[#6B655E] shrink-0">
                      {d.items.length}곳
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </aside>
      </div>
    </main>
  );
}
