import { APIProvider } from "@vis.gl/react-google-maps";
import { FileArchive, Loader2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { AIRecommenderModal } from "./components/AIRecommenderModal";
import { AppendixView } from "./components/AppendixView";
import { DayRailSidebar } from "./components/DayRailSidebar";
import { EditorialHero } from "./components/EditorialHero";
import { InspectorPanel } from "./components/InspectorPanel";
import { MagazineView } from "./components/MagazineView";
import { MapRouteView } from "./components/MapRouteView";
import { NewTripModal } from "./components/NewTripModal";
import { TimelineSection } from "./components/TimelineSection";
import { TopBar } from "./components/TopBar";
import { TripLibraryView } from "./components/TripLibraryView";
import { SEED_TRIPS } from "./data/seedTrips";
import type {
  AIDayRebalanceResponse,
  AIRecommendResponse,
  AppViewMode,
  CompanionType,
  ItineraryItem,
  LatLngLiteral,
  PaceType,
  Trip,
} from "./types/travel";
import { downloadSourceCodeZip, fetchMapsApiKey } from "./utils/api";
import { decodeTripFromShareHash } from "./utils/share";
import {
  createId,
  loadActiveTripId,
  loadTripsFromStorage,
  saveActiveTripId,
  saveTripsToStorage,
} from "./utils/storage";

export default function App() {
  const [trips, setTrips] = useState<Trip[]>(() => loadTripsFromStorage());
  const [activeTripId, setActiveTripId] = useState<string>(() =>
    loadActiveTripId(loadTripsFromStorage())
  );
  const [viewMode, setViewMode] = useState<AppViewMode>("editor");
  const [selectedDayFilter, setSelectedDayFilter] = useState<number | "all">("all");
  const [selectedSlot, setSelectedSlot] = useState<{
    dayNumber: number;
    itemId: string;
  } | null>(null);
  const [aiSuggestTriggerDay, setAiSuggestTriggerDay] = useState<number | null>(null);
  const [mapFocusDay, setMapFocusDay] = useState<number>(1);

  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isNewTripModalOpen, setIsNewTripModalOpen] = useState(false);
  const [importNotice, setImportNotice] = useState<string | null>(null);

  const [mapsApiKey, setMapsApiKey] = useState<string>("");
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [sharedTripBanner, setSharedTripBanner] = useState<Trip | null>(null);
  const [isDownloadingSource, setIsDownloadingSource] = useState(false);
  const [sourceDownloadError, setSourceDownloadError] = useState<string | null>(null);

  useEffect(() => {
    fetchMapsApiKey().then((key) => {
      if (key) setMapsApiKey(key);
    });
  }, []);

  useEffect(() => {
    const onQuotaExceeded = () => setMapsQuotaExceeded(true);
    window.addEventListener("gmp-quota-exceeded", onQuotaExceeded);
    return () => window.removeEventListener("gmp-quota-exceeded", onQuotaExceeded);
  }, []);

  useEffect(() => {
    const checkShareHash = () => {
      const decoded = decodeTripFromShareHash(window.location.hash);
      if (decoded) {
        setSharedTripBanner(decoded);
      }
    };
    checkShareHash();
    window.addEventListener("hashchange", checkShareHash);
    return () => window.removeEventListener("hashchange", checkShareHash);
  }, []);

  useEffect(() => {
    saveTripsToStorage(trips);
  }, [trips]);

  useEffect(() => {
    if (activeTripId) {
      saveActiveTripId(activeTripId);
    }
  }, [activeTripId]);

  const activeTrip = useMemo(() => {
    return trips.find((t) => t.id === activeTripId) ?? trips[0];
  }, [trips, activeTripId]);

  const selectedItem = useMemo(() => {
    if (!selectedSlot || !activeTrip) return null;
    const day = activeTrip.days.find((d) => d.dayNumber === selectedSlot.dayNumber);
    return day?.items.find((i) => i.id === selectedSlot.itemId) ?? null;
  }, [activeTrip, selectedSlot]);

  const updateActiveTrip = (updater: (trip: Trip) => Trip) => {
    if (!activeTrip) return;
    setTrips((prev) =>
      prev.map((t) =>
        t.id === activeTrip.id
          ? { ...updater(t), updatedAt: new Date().toISOString() }
          : t
      )
    );
  };

  const handleUpdateTripMeta = (patch: Partial<Trip>) => {
    updateActiveTrip((trip) => ({ ...trip, ...patch }));
  };

  const handleAddDay = () => {
    updateActiveTrip((trip) => {
      const nextNum =
        trip.days.length > 0
          ? Math.max(...trip.days.map((d) => d.dayNumber)) + 1
          : 1;
      return {
        ...trip,
        days: [
          ...trip.days,
          {
            dayNumber: nextNum,
            title: `${nextNum}일차의 새로운 여정`,
            summary: "",
            items: [],
          },
        ],
      };
    });
  };

  const handleDeleteDay = (dayNumber: number) => {
    updateActiveTrip((trip) => {
      const filtered = trip.days
        .filter((d) => d.dayNumber !== dayNumber)
        .map((d, idx) => ({ ...d, dayNumber: idx + 1 }));
      return { ...trip, days: filtered };
    });
    if (selectedDayFilter === dayNumber) {
      setSelectedDayFilter("all");
    }
    if (selectedSlot?.dayNumber === dayNumber) {
      setSelectedSlot(null);
    }
  };

  const handleUpdateDayMeta = (
    dayNumber: number,
    patch: { title?: string; summary?: string }
  ) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) =>
        d.dayNumber === dayNumber ? { ...d, ...patch } : d
      ),
    }));
  };

  const handleApplyRebalancedDay = (
    dayNumber: number,
    result: AIDayRebalanceResponse
  ) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) =>
        d.dayNumber === dayNumber
          ? {
              ...d,
              title: result.title || d.title,
              summary: result.summary || d.summary,
              items: result.items.map((item) => ({
                ...item,
                id: createId("spot"),
                completed: false,
              })),
            }
          : d
      ),
    }));
    setSelectedSlot(null);
  };

  const handleAddItem = (dayNumber: number) => {
    const newId = createId("spot");
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) => {
        if (d.dayNumber !== dayNumber) return d;
        const lastTime = d.items[d.items.length - 1]?.time;
        let nextTime = "10:00";
        if (lastTime && /^\d{2}:\d{2}$/.test(lastTime)) {
          const [hh, mm] = lastTime.split(":").map(Number);
          const nextHour = Math.min(22, hh + 2);
          nextTime = `${String(nextHour).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
        }
        const newItem: ItineraryItem = {
          id: newId,
          time: nextTime,
          durationMinutes: 60,
          title: "새로운 방문 장소",
          category: "관광",
          area: trip.destination,
          note: "",
          transitTip: "",
          estimatedCost: 0,
          completed: false,
        };
        return { ...d, items: [...d.items, newItem] };
      }),
    }));
    setSelectedSlot({ dayNumber, itemId: newId });
  };

  const handleInsertSuggestedItem = (
    dayNumber: number,
    item: Omit<ItineraryItem, "id" | "completed">
  ) => {
    const newId = createId("spot");
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) => {
        if (d.dayNumber !== dayNumber) return d;
        const nextItems = [
          ...d.items,
          { ...item, id: newId, completed: false },
        ].sort((a, b) => a.time.localeCompare(b.time));
        return { ...d, items: nextItems };
      }),
    }));
    setSelectedSlot({ dayNumber, itemId: newId });
  };

  const handleUpdateItem = (
    dayNumber: number,
    itemId: string,
    patch: Partial<ItineraryItem>
  ) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) =>
        d.dayNumber === dayNumber
          ? {
              ...d,
              items: d.items.map((item) =>
                item.id === itemId ? { ...item, ...patch } : item
              ),
            }
          : d
      ),
    }));
  };

  const handleUpdateItemLocation = (
    dayNumber: number,
    itemId: string,
    patch: {
      placeId?: string;
      formattedAddress?: string;
      location?: LatLngLiteral;
    }
  ) => {
    handleUpdateItem(dayNumber, itemId, patch);
  };

  const handleToggleComplete = (dayNumber: number, itemId: string) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) =>
        d.dayNumber === dayNumber
          ? {
              ...d,
              items: d.items.map((item) =>
                item.id === itemId
                  ? { ...item, completed: !item.completed }
                  : item
              ),
            }
          : d
      ),
    }));
  };

  const handleMoveItem = (
    dayNumber: number,
    itemId: string,
    direction: "up" | "down"
  ) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) => {
        if (d.dayNumber !== dayNumber) return d;
        const idx = d.items.findIndex((i) => i.id === itemId);
        if (idx === -1) return d;
        const targetIdx = direction === "up" ? idx - 1 : idx + 1;
        if (targetIdx < 0 || targetIdx >= d.items.length) return d;
        const copy = [...d.items];
        const [moved] = copy.splice(idx, 1);
        copy.splice(targetIdx, 0, moved);
        return { ...d, items: copy };
      }),
    }));
  };

  const handleMoveItemToDay = (
    fromDay: number,
    toDay: number,
    itemId: string
  ) => {
    if (fromDay === toDay) return;
    let movedItem: ItineraryItem | null = null;
    updateActiveTrip((trip) => {
      const withoutSource = trip.days.map((d) => {
        if (d.dayNumber !== fromDay) return d;
        const found = d.items.find((i) => i.id === itemId);
        if (found) movedItem = found;
        return { ...d, items: d.items.filter((i) => i.id !== itemId) };
      });
      if (!movedItem) return trip;
      return {
        ...trip,
        days: withoutSource.map((d) =>
          d.dayNumber === toDay
            ? { ...d, items: [...d.items, movedItem!] }
            : d
        ),
      };
    });
    setSelectedSlot({ dayNumber: toDay, itemId });
  };

  const handleDeleteItem = (dayNumber: number, itemId: string) => {
    updateActiveTrip((trip) => ({
      ...trip,
      days: trip.days.map((d) =>
        d.dayNumber === dayNumber
          ? { ...d, items: d.items.filter((i) => i.id !== itemId) }
          : d
      ),
    }));
    if (selectedSlot?.itemId === itemId) {
      setSelectedSlot(null);
    }
  };

  const handleCreateBlankTrip = (payload: {
    title: string;
    destination: string;
    startDate: string;
    endDate: string;
    daysCount: number;
    companions: CompanionType;
    pace: PaceType;
    journalNote: string;
    coverImage: string;
    coverCaption: string;
  }) => {
    const newTrip: Trip = {
      id: createId("trip"),
      title: payload.title,
      destination: payload.destination,
      startDate: payload.startDate,
      endDate: payload.endDate,
      companions: payload.companions,
      pace: payload.pace,
      coverImage: payload.coverImage,
      coverCaption: payload.coverCaption,
      journalNote: payload.journalNote,
      travelers: ["나"],
      expenses: [],
      packingList: [],
      reservations: [],
      updatedAt: new Date().toISOString(),
      days: Array.from({ length: payload.daysCount }, (_, idx) => ({
        dayNumber: idx + 1,
        title: `${idx + 1}일차 여정`,
        summary: "",
        items: [],
      })),
    };
    setTrips((prev) => [newTrip, ...prev]);
    setActiveTripId(newTrip.id);
    setSelectedDayFilter("all");
    setSelectedSlot(null);
    setViewMode("editor");
    setIsNewTripModalOpen(false);
  };

  const handleCreateNewTripFromAI = (
    result: AIRecommendResponse,
    meta: {
      destination: string;
      companions: CompanionType;
      pace: PaceType;
      coverImage: string;
      coverCaption: string;
    }
  ) => {
    const today = new Date();
    const end = new Date(today);
    end.setDate(today.getDate() + Math.max(0, result.days.length - 1));
    const fmt = (d: Date) => d.toISOString().slice(0, 10);

    const newTrip: Trip = {
      id: createId("trip"),
      title: result.title,
      destination: meta.destination,
      startDate: fmt(today),
      endDate: fmt(end),
      companions: meta.companions,
      pace: meta.pace,
      coverImage: meta.coverImage,
      coverCaption: meta.coverCaption,
      journalNote: result.journalNote,
      travelers: meta.companions === "혼자" ? ["나"] : ["나", "동행자"],
      expenses: [],
      packingList: [],
      reservations: [],
      updatedAt: new Date().toISOString(),
      days: result.days.map((day, idx) => ({
        dayNumber: day.dayNumber || idx + 1,
        title: day.title,
        summary: day.summary,
        items: day.items.map((item) => ({
          ...item,
          id: createId("spot"),
          completed: false,
        })),
      })),
    };

    setTrips((prev) => [newTrip, ...prev]);
    setActiveTripId(newTrip.id);
    setSelectedDayFilter("all");
    setSelectedSlot(null);
    setViewMode("editor");
    setIsAIModalOpen(false);
  };

  const handleApplyAIToCurrentTrip = (result: AIRecommendResponse) => {
    updateActiveTrip((trip) => ({
      ...trip,
      title: result.title || trip.title,
      journalNote: result.journalNote || trip.journalNote,
      days: result.days.map((day, idx) => ({
        dayNumber: day.dayNumber || idx + 1,
        title: day.title,
        summary: day.summary,
        items: day.items.map((item) => ({
          ...item,
          id: createId("spot"),
          completed: false,
        })),
      })),
    }));
    setSelectedDayFilter("all");
    setSelectedSlot(null);
    setViewMode("editor");
    setIsAIModalOpen(false);
  };

  const handleImportSharedTrip = () => {
    if (!sharedTripBanner) return;
    const imported: Trip = {
      ...sharedTripBanner,
      id: createId("trip"),
      updatedAt: new Date().toISOString(),
    };
    setTrips((prev) => [imported, ...prev]);
    setActiveTripId(imported.id);
    setSharedTripBanner(null);
    window.history.replaceState(null, "", window.location.pathname);
    setViewMode("editor");
  };

  const handleExportTrip = () => {
    if (!activeTrip) return;
    const blob = new Blob([JSON.stringify(activeTrip, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeTrip.destination.replace(/\s+/g, "_")}_travel_journal.json`;
    a.click();
    URL.revokeObjectURL(url);
    setImportNotice("JSON 파일로 내보냈습니다.");
    setTimeout(() => setImportNotice(null), 3000);
  };

  const handleDownloadSource = async () => {
    if (isDownloadingSource) return;
    setIsDownloadingSource(true);
    setSourceDownloadError(null);
    try {
      await downloadSourceCodeZip();
      setImportNotice("소스코드 ZIP 다운로드를 시작했습니다.");
      setTimeout(() => setImportNotice(null), 3000);
    } catch (err) {
      setSourceDownloadError(
        err instanceof Error ? err.message : "다운로드 중 오류가 발생했습니다."
      );
    } finally {
      setIsDownloadingSource(false);
    }
  };

  const handleImportTrips = async (file: File) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as unknown;
      const list = Array.isArray(parsed) ? parsed : [parsed];
      const valid = list.filter(
        (item): item is Trip =>
          typeof item === "object" &&
          item !== null &&
          typeof (item as Trip).title === "string" &&
          Array.isArray((item as Trip).days)
      );
      if (valid.length === 0) {
        setImportNotice("유효한 여행 저널 JSON 형식이 아닙니다.");
        return;
      }
      const reindexed = valid.map((t) => ({
        ...t,
        id: createId("trip"),
        updatedAt: new Date().toISOString(),
      }));
      setTrips((prev) => [...reindexed, ...prev]);
      setActiveTripId(reindexed[0].id);
      setSelectedDayFilter("all");
      setSelectedSlot(null);
      setImportNotice(`${reindexed.length}개의 여행을 불러왔습니다.`);
      setTimeout(() => setImportNotice(null), 3500);
    } catch {
      setImportNotice("JSON 파일을 읽는 중 오류가 발생했습니다.");
    }
  };

  const handleDuplicateTrip = (tripId: string) => {
    const source = trips.find((t) => t.id === tripId);
    if (!source) return;
    const cloned: Trip = {
      ...source,
      id: createId("trip"),
      title: `${source.title} (사본)`,
      updatedAt: new Date().toISOString(),
      days: source.days.map((d) => ({
        ...d,
        items: d.items.map((i) => ({ ...i, id: createId("spot") })),
      })),
    };
    setTrips((prev) => [cloned, ...prev]);
    setActiveTripId(cloned.id);
    setViewMode("editor");
  };

  const handleDeleteTrip = (tripId: string) => {
    if (trips.length <= 1) return;
    const remaining = trips.filter((t) => t.id !== tripId);
    setTrips(remaining);
    if (activeTripId === tripId) {
      setActiveTripId(remaining[0].id);
      setSelectedDayFilter("all");
      setSelectedSlot(null);
    }
  };

  const handleRestoreSeeds = () => {
    setTrips((prev) => {
      const existingIds = new Set(prev.map((t) => t.id));
      const missingSeeds = SEED_TRIPS.filter((s) => !existingIds.has(s.id));
      return missingSeeds.length > 0 ? [...prev, ...missingSeeds] : prev;
    });
  };

  const activeInspectorDay =
    selectedSlot?.dayNumber ??
    (selectedDayFilter === "all"
      ? activeTrip?.days[0]?.dayNumber ?? 1
      : selectedDayFilter);

  const content = (
    <div className="min-h-screen flex flex-col bg-[#FBF9F5] text-[#1C1917]">
      {mapsQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{" "}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{" "}
            for instructions to update your account.
          </span>
        </div>
      )}

      {sharedTripBanner && (
        <div className="no-print bg-[#F3EFE6] border-b border-[#1B4332]/30 px-4 sm:px-6 lg:px-8 py-3">
          <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <p className="text-[#1C1917]">
              공유된 여행 저널 <strong>“{sharedTripBanner.title}”</strong> (
              {sharedTripBanner.destination}) 링크가 열렸습니다. 내 여행 서가에 저장하시겠습니까?
            </p>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setSharedTripBanner(null);
                  window.history.replaceState(null, "", window.location.pathname);
                }}
                className="px-3 py-1.5 border border-[#D4CBB8] bg-[#FFFFFF] rounded-md text-[#4A453F] cursor-pointer"
              >
                닫기
              </button>
              <button
                type="button"
                onClick={handleImportSharedTrip}
                className="px-3.5 py-1.5 bg-[#1B4332] text-[#FBF9F5] rounded-md font-medium cursor-pointer"
              >
                내 여행 서가에 저장하기
              </button>
            </div>
          </div>
        </div>
      )}

      <TopBar
        viewMode={viewMode}
        onSelectView={setViewMode}
        onOpenNewTrip={() => setIsNewTripModalOpen(true)}
      />

      {viewMode === "editor" && activeTrip && (
        <>
          <EditorialHero
            trip={activeTrip}
            onUpdateTripMeta={handleUpdateTripMeta}
            onOpenAIPlanner={() => setIsAIModalOpen(true)}
            onOpenMapView={() => {
              setMapFocusDay(
                selectedDayFilter === "all"
                  ? activeTrip.days[0]?.dayNumber ?? 1
                  : selectedDayFilter
              );
              setViewMode("map");
            }}
          />

          <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
            <div className="flex flex-col lg:flex-row gap-6 lg:gap-8 items-start">
              <DayRailSidebar
                trip={activeTrip}
                selectedDay={selectedDayFilter}
                onSelectDay={(d) => {
                  setSelectedDayFilter(d);
                  setSelectedSlot(null);
                }}
                onAddDay={handleAddDay}
                onExportTrip={handleExportTrip}
                onImportTrips={handleImportTrips}
                onOpenAppendix={() => setViewMode("appendix")}
                onDownloadSource={handleDownloadSource}
                isDownloadingSource={isDownloadingSource}
                importNotice={importNotice}
              />

              <TimelineSection
                destination={activeTrip.destination}
                companions={activeTrip.companions}
                days={activeTrip.days}
                selectedDayFilter={selectedDayFilter}
                selectedItemId={selectedSlot?.itemId ?? null}
                onSelectItem={(dayNumber, itemId) =>
                  setSelectedSlot({ dayNumber, itemId })
                }
                onToggleComplete={handleToggleComplete}
                onMoveItem={handleMoveItem}
                onDeleteItem={handleDeleteItem}
                onAddItem={handleAddItem}
                onUpdateDayMeta={handleUpdateDayMeta}
                onDeleteDay={handleDeleteDay}
                canDeleteDay={activeTrip.days.length > 1}
                onRequestDayAISuggest={(dayNumber) =>
                  setAiSuggestTriggerDay(dayNumber)
                }
                onApplyRebalancedDay={handleApplyRebalancedDay}
                onOpenDayOnMap={(dayNumber) => {
                  setMapFocusDay(dayNumber);
                  setViewMode("map");
                }}
              />

              <InspectorPanel
                trip={activeTrip}
                mapsEnabled={Boolean(mapsApiKey)}
                selectedDayNumber={activeInspectorDay}
                selectedItem={selectedItem}
                aiSuggestTriggerDay={aiSuggestTriggerDay}
                onClearAiTrigger={() => setAiSuggestTriggerDay(null)}
                onClearSelection={() => setSelectedSlot(null)}
                onUpdateItem={handleUpdateItem}
                onMoveItemToDay={handleMoveItemToDay}
                onDeleteItem={handleDeleteItem}
                onInsertSuggestedItem={handleInsertSuggestedItem}
              />
            </div>
          </main>
        </>
      )}

      {viewMode === "map" && activeTrip && (
        <MapRouteView
          trip={activeTrip}
          mapsApiKey={mapsApiKey}
          initialDayNumber={mapFocusDay}
          onUpdateItemLocation={handleUpdateItemLocation}
          onBackToEditor={() => setViewMode("editor")}
        />
      )}

      {viewMode === "appendix" && activeTrip && (
        <AppendixView trip={activeTrip} onUpdateTrip={handleUpdateTripMeta} />
      )}

      {viewMode === "magazine" && activeTrip && (
        <MagazineView
          trip={activeTrip}
          onBackToEditor={() => setViewMode("editor")}
        />
      )}

      {viewMode === "library" && (
        <TripLibraryView
          trips={trips}
          activeTripId={activeTrip?.id ?? ""}
          onSelectTrip={(id) => {
            setActiveTripId(id);
            setSelectedDayFilter("all");
            setSelectedSlot(null);
            setViewMode("editor");
          }}
          onDuplicateTrip={handleDuplicateTrip}
          onDeleteTrip={handleDeleteTrip}
          onRestoreSeeds={handleRestoreSeeds}
          onOpenNewTrip={() => setIsNewTripModalOpen(true)}
          onOpenAIPlanner={() => setIsAIModalOpen(true)}
        />
      )}

      <footer className="no-print border-t border-[#E5DFD3] py-5 mt-auto">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#6B655E]">
          <span className="font-editorial">여백의 여정 — Travel Journal Planner</span>
          <div className="flex flex-wrap items-center gap-4">
            <span>모든 여행 데이터는 로그인 없이 현재 브라우저에 로컬 저장됩니다.</span>
            {sourceDownloadError && (
              <span className="text-[#B91C1C]">{sourceDownloadError}</span>
            )}
            <button
              type="button"
              disabled={isDownloadingSource}
              onClick={handleDownloadSource}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#1B4332] bg-[#F3EFE6] border border-[#1B4332]/30 rounded-md hover:bg-[#1B4332]/10 disabled:opacity-60 transition-colors cursor-pointer whitespace-nowrap"
            >
              {isDownloadingSource ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                  <span>압축 중...</span>
                </>
              ) : (
                <>
                  <FileArchive className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>소스코드 다운로드 (.zip)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </footer>

      <AIRecommenderModal
        isOpen={isAIModalOpen}
        hasActiveTrip={Boolean(activeTrip)}
        onClose={() => setIsAIModalOpen(false)}
        onCreateNewTripFromAI={handleCreateNewTripFromAI}
        onApplyToCurrentTrip={handleApplyAIToCurrentTrip}
      />

      <NewTripModal
        isOpen={isNewTripModalOpen}
        onClose={() => setIsNewTripModalOpen(false)}
        onCreateBlankTrip={handleCreateBlankTrip}
        onSwitchToAI={() => {
          setIsNewTripModalOpen(false);
          setIsAIModalOpen(true);
        }}
      />
    </div>
  );

  if (mapsApiKey) {
    return (
      <APIProvider
        apiKey={mapsApiKey}
        language="ko"
        region="KR"
        libraries={["places", "marker", "routes"]}
      >
        {content}
      </APIProvider>
    );
  }

  return content;
}
