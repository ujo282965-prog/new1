export type CompanionType = "혼자" | "친구" | "가족" | "연인";

export type PaceType = "여유롭게" | "균형 있게" | "알차게";

export type ItineraryCategory =
  | "관광"
  | "미식"
  | "카페"
  | "숙소"
  | "이동"
  | "쇼핑"
  | "휴식";

export interface LatLngLiteral {
  lat: number;
  lng: number;
}

export interface ItineraryItem {
  id: string;
  time: string;
  durationMinutes: number;
  title: string;
  category: ItineraryCategory;
  area: string;
  note: string;
  transitTip: string;
  estimatedCost: number;
  completed: boolean;
  placeId?: string;
  formattedAddress?: string;
  location?: LatLngLiteral;
}

export interface TripDay {
  dayNumber: number;
  title: string;
  summary: string;
  items: ItineraryItem[];
}

export interface ExpenseEntry {
  id: string;
  title: string;
  amount: number;
  category: ItineraryCategory;
  paidBy: string;
  splitAmong: string[];
  dayNumber: number;
  note: string;
}

export type PackingCategory =
  | "필수 서류"
  | "의류"
  | "전자기기"
  | "세면·상비약"
  | "기타";

export interface PackingItem {
  id: string;
  label: string;
  category: PackingCategory;
  checked: boolean;
}

export type ReservationType =
  | "항공·기차"
  | "숙소"
  | "투어·티켓"
  | "식당·기타";

export interface ReservationItem {
  id: string;
  type: ReservationType;
  title: string;
  dateTime: string;
  confirmationCode: string;
  location: string;
  note: string;
}

export interface Trip {
  id: string;
  title: string;
  destination: string;
  startDate: string;
  endDate: string;
  companions: CompanionType;
  pace: PaceType;
  coverImage: string;
  coverCaption: string;
  journalNote: string;
  days: TripDay[];
  travelers?: string[];
  expenses?: ExpenseEntry[];
  packingList?: PackingItem[];
  reservations?: ReservationItem[];
  updatedAt: string;
}

export type AppViewMode =
  | "editor"
  | "map"
  | "appendix"
  | "magazine"
  | "library";

export type RebalanceMode = "rainy_indoor" | "optimize_route" | "relaxed_pace";

export interface AIRecommendPayload {
  destination: string;
  daysCount: number;
  companions: CompanionType;
  pace: PaceType;
  themes: string[];
  extraNotes: string;
}

export interface AIRecommendResponse {
  title: string;
  journalNote: string;
  days: Array<{
    dayNumber: number;
    title: string;
    summary: string;
    items: Array<Omit<ItineraryItem, "id" | "completed">>;
  }>;
}

export interface AISpotSuggestionResponse {
  suggestions: Array<Omit<ItineraryItem, "id" | "completed">>;
}

export interface AIDayRebalanceResponse {
  title: string;
  summary: string;
  reason: string;
  items: Array<Omit<ItineraryItem, "id" | "completed">>;
}
