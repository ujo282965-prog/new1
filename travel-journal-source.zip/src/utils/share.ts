import type { Trip } from "../types/travel";

function uint8ToBase64Url(bytes: Uint8Array): string {
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlToUint8(str: string): Uint8Array {
  const padded = str.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((str.length + 3) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

export function encodeTripToShareHash(trip: Trip): string {
  const json = JSON.stringify(trip);
  const bytes = new TextEncoder().encode(json);
  return `#share=${uint8ToBase64Url(bytes)}`;
}

export function decodeTripFromShareHash(hash: string): Trip | null {
  try {
    if (!hash || !hash.startsWith("#share=")) return null;
    const payload = hash.slice("#share=".length);
    if (!payload) return null;
    const bytes = base64UrlToUint8(payload);
    const json = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(json) as unknown;
    if (
      typeof parsed === "object" &&
      parsed !== null &&
      typeof (parsed as Trip).title === "string" &&
      Array.isArray((parsed as Trip).days)
    ) {
      return parsed as Trip;
    }
    return null;
  } catch {
    return null;
  }
}
