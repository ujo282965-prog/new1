import { SEED_TRIPS } from "../data/seedTrips";
import type { Trip } from "../types/travel";

const TRIPS_STORAGE_KEY = "yeobaek_travel_journals_v1";
const ACTIVE_TRIP_KEY = "yeobaek_active_trip_id_v1";

export function loadTripsFromStorage(): Trip[] {
  try {
    const raw = window.localStorage.getItem(TRIPS_STORAGE_KEY);
    if (!raw) {
      window.localStorage.setItem(TRIPS_STORAGE_KEY, JSON.stringify(SEED_TRIPS));
      return SEED_TRIPS;
    }
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return SEED_TRIPS;
    }
    return parsed as Trip[];
  } catch {
    return SEED_TRIPS;
  }
}

export function saveTripsToStorage(trips: Trip[]): void {
  try {
    window.localStorage.setItem(TRIPS_STORAGE_KEY, JSON.stringify(trips));
  } catch {
    // Ignore storage quota issues gracefully
  }
}

export function loadActiveTripId(trips: Trip[]): string {
  try {
    const saved = window.localStorage.getItem(ACTIVE_TRIP_KEY);
    if (saved && trips.some((t) => t.id === saved)) {
      return saved;
    }
  } catch {
    // Fallback below
  }
  return trips[0]?.id ?? "";
}

export function saveActiveTripId(tripId: string): void {
  try {
    window.localStorage.setItem(ACTIVE_TRIP_KEY, tripId);
  } catch {
    // Ignore
  }
}

export function createId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function formatWon(amount: number): string {
  if (!amount || amount <= 0) return "무료";
  return `${amount.toLocaleString("ko-KR")}원`;
}

export function calculateNightsAndDays(startDate: string, endDate: string, daysLength: number): string {
  if (daysLength <= 1) return "당일치기";
  return `${daysLength - 1}박 ${daysLength}일`;
}

export function formatDateRange(startDate: string, endDate: string): string {
  if (!startDate && !endDate) return "일정 미정";
  const formatOne = (d: string) => d.replace(/-/g, ".");
  if (startDate && endDate) {
    return `${formatOne(startDate)} – ${formatOne(endDate)}`;
  }
  return formatOne(startDate || endDate);
}
