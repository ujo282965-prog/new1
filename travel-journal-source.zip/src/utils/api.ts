import type {
  AIDayRebalanceResponse,
  AIRecommendPayload,
  AIRecommendResponse,
  AISpotSuggestionResponse,
  ItineraryItem,
  RebalanceMode,
} from "../types/travel";

export async function fetchMapsApiKey(): Promise<string> {
  const buildKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
  if (buildKey && buildKey !== "MY_GOOGLE_MAPS_API_KEY") {
    return buildKey;
  }
  try {
    const res = await fetch("/api/maps-config");
    if (!res.ok) return "";
    const data = (await res.json()) as { apiKey?: string };
    return data.apiKey || "";
  } catch {
    return "";
  }
}

export async function requestAIItinerary(
  payload: AIRecommendPayload
): Promise<AIRecommendResponse> {
  const response = await fetch("/api/ai/recommend", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = (await response.json().catch(() => ({}))) as AIRecommendResponse & {
    error?: string;
  };

  if (!response.ok) {
    throw new Error(data.error || "AI 맞춤 여행 코스를 불러오지 못했습니다.");
  }

  return data;
}

export async function requestAISpotSuggestions(payload: {
  destination: string;
  dayNumber: number;
  dayTitle: string;
  existingTitles: string[];
  companions: string;
  requestNote: string;
}): Promise<AISpotSuggestionResponse> {
  const response = await fetch("/api/ai/suggest-spot", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = (await response.json().catch(() => ({}))) as AISpotSuggestionResponse & {
    error?: string;
  };

  if (!response.ok) {
    throw new Error(data.error || "AI 장소 추천을 불러오지 못했습니다.");
  }

  return data;
}

export async function requestAIDayRebalance(payload: {
  destination: string;
  dayNumber: number;
  dayTitle: string;
  companions: string;
  mode: RebalanceMode;
  customInstruction?: string;
  items: ItineraryItem[];
}): Promise<AIDayRebalanceResponse> {
  const response = await fetch("/api/ai/rebalance-day", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = (await response.json().catch(() => ({}))) as AIDayRebalanceResponse & {
    error?: string;
  };

  if (!response.ok) {
    throw new Error(data.error || "AI 일정 리밸런싱을 수행하지 못했습니다.");
  }

  return data;
}

export async function downloadSourceCodeZip(): Promise<void> {
  const response = await fetch("/api/source-download");
  if (!response.ok) {
    const errBody = (await response.json().catch(() => ({}))) as { error?: string };
    throw new Error(errBody.error || "소스코드 ZIP 파일을 다운로드하지 못했습니다.");
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "travel-journal-source.zip";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
