import "dotenv/config";
import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import zlib from "zlib";
import { GoogleGenAI, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const MODEL_NAME = "gemini-4-hydrogen";

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function extractUpstreamError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw.includes("403") || raw.includes("PERMISSION_DENIED") || raw.includes("API_KEY_INVALID")) {
    return {
      status: 403,
      message: "Gemini API 키 인증에 실패했습니다. Settings > Secrets 패널에서 GEMINI_API_KEY를 확인해 주세요.",
    };
  }
  if (raw.includes("429") || raw.includes("RESOURCE_EXHAUSTED")) {
    return {
      status: 429,
      message: "AI 요청 할당량을 초과했습니다. 잠시 후 다시 시도해 주세요.",
    };
  }
  if (raw.includes("404") || raw.includes("NOT_FOUND")) {
    return {
      status: 502,
      message: "요청한 AI 모델을 찾을 수 없습니다. 잠시 후 다시 시도해 주세요.",
    };
  }
  return {
    status: 500,
    message: "AI 여행 코스를 생성하는 중 오류가 발생했습니다. 다시 시도해 주세요.",
  };
}

interface RecommendRequestBody {
  destination?: string;
  daysCount?: number;
  companions?: string;
  pace?: string;
  themes?: string[];
  extraNotes?: string;
}

interface SuggestSpotRequestBody {
  destination?: string;
  dayNumber?: number;
  dayTitle?: string;
  existingTitles?: string[];
  companions?: string;
  requestNote?: string;
}

interface RebalanceDayRequestBody {
  destination?: string;
  dayNumber?: number;
  dayTitle?: string;
  companions?: string;
  mode?: "rainy_indoor" | "optimize_route" | "relaxed_pace";
  customInstruction?: string;
  items?: Array<{
    time: string;
    durationMinutes: number;
    title: string;
    category: string;
    area: string;
    note: string;
    transitTip: string;
    estimatedCost: number;
  }>;
}

const VALID_CATEGORIES = ["관광", "미식", "카페", "숙소", "이동", "쇼핑", "휴식"];

function normalizeCategory(cat: string | undefined): string {
  if (!cat) return "관광";
  return VALID_CATEGORIES.includes(cat) ? cat : "관광";
}

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosTimeDate(date: Date): { dosTime: number; dosDate: number } {
  const year = Math.max(1980, date.getFullYear());
  const dosTime =
    ((date.getHours() & 0x1f) << 11) |
    ((date.getMinutes() & 0x3f) << 5) |
    ((date.getSeconds() >> 1) & 0x1f);
  const dosDate =
    (((year - 1980) & 0x7f) << 9) |
    (((date.getMonth() + 1) & 0x0f) << 5) |
    (date.getDate() & 0x1f);
  return { dosTime, dosDate };
}

function buildZipBuffer(
  entries: Array<{ name: string; data: Buffer; mtime: Date }>
): Buffer {
  const localChunks: Buffer[] = [];
  const centralChunks: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const nameBuf = Buffer.from(entry.name, "utf8");
    const compressed = zlib.deflateRawSync(entry.data);
    const crc = crc32(entry.data);
    const { dosTime, dosDate } = toDosTimeDate(entry.mtime);

    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4); // version needed
    localHeader.writeUInt16LE(0x0800, 6); // UTF-8 filename flag
    localHeader.writeUInt16LE(8, 8); // deflate
    localHeader.writeUInt16LE(dosTime, 10);
    localHeader.writeUInt16LE(dosDate, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(entry.data.length, 22);
    localHeader.writeUInt16LE(nameBuf.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localChunks.push(localHeader, nameBuf, compressed);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4); // version made by
    centralHeader.writeUInt16LE(20, 6); // version needed
    centralHeader.writeUInt16LE(0x0800, 8); // UTF-8 filename flag
    centralHeader.writeUInt16LE(8, 10); // deflate
    centralHeader.writeUInt16LE(dosTime, 12);
    centralHeader.writeUInt16LE(dosDate, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(compressed.length, 20);
    centralHeader.writeUInt32LE(entry.data.length, 24);
    centralHeader.writeUInt16LE(nameBuf.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralChunks.push(centralHeader, nameBuf);
    offset += localHeader.length + nameBuf.length + compressed.length;
  }

  const centralDir = Buffer.concat(centralChunks);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralDir.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localChunks, centralDir, eocd]);
}

const ALLOWED_ROOT_FILES = [
  "index.html",
  "package.json",
  "tsconfig.json",
  "vite.config.ts",
  "server.ts",
  "metadata.json",
  ".env.example",
  ".gitignore",
];

function collectAllowlistedSourceFiles(
  rootDir: string
): Array<{ name: string; data: Buffer; mtime: Date }> {
  const resolvedRoot = path.resolve(rootDir);
  const collected: Array<{ name: string; data: Buffer; mtime: Date }> = [];
  const MAX_FILE_BYTES = 10 * 1024 * 1024;

  const pushIfSafe = (absPath: string, relName: string) => {
    const resolved = path.resolve(absPath);
    if (!resolved.startsWith(resolvedRoot + path.sep)) return;
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink() || !stat.isFile() || stat.size > MAX_FILE_BYTES) return;
    collected.push({
      name: relName.split(path.sep).join("/"),
      data: fs.readFileSync(resolved),
      mtime: stat.mtime,
    });
  };

  for (const filename of ALLOWED_ROOT_FILES) {
    const abs = path.join(resolvedRoot, filename);
    if (fs.existsSync(abs)) {
      pushIfSafe(abs, filename);
    }
  }

  const walkDir = (dirAbs: string, relPrefix: string) => {
    if (!fs.existsSync(dirAbs)) return;
    const dirents = fs.readdirSync(dirAbs, { withFileTypes: true });
    for (const dirent of dirents) {
      if (dirent.isSymbolicLink() || dirent.name.startsWith(".")) continue;
      const childAbs = path.join(dirAbs, dirent.name);
      const childRel = path.join(relPrefix, dirent.name);
      if (dirent.isDirectory()) {
        walkDir(childAbs, childRel);
      } else if (dirent.isFile()) {
        pushIfSafe(childAbs, childRel);
      }
    }
  };

  walkDir(path.join(resolvedRoot, "src"), "src");
  return collected;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true });
  });

  app.get("/api/maps-config", (_req, res) => {
    const apiKey =
      process.env.VITE_GOOGLE_MAPS_API_KEY ||
      process.env.GOOGLE_MAPS_API_KEY ||
      "";
    const cleanKey =
      apiKey === "MY_GOOGLE_MAPS_API_KEY" ? "" : apiKey;
    res.json({ apiKey: cleanKey });
  });

  app.get("/api/source-download", (_req, res) => {
    try {
      const files = collectAllowlistedSourceFiles(__dirname);
      if (files.length === 0) {
        res.status(404).json({ error: "다운로드할 소스 파일을 찾지 못했습니다." });
        return;
      }
      const zipBuffer = buildZipBuffer(files);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="travel-journal-source.zip"'
      );
      res.setHeader("Content-Length", String(zipBuffer.length));
      res.setHeader("Cache-Control", "no-store");
      res.send(zipBuffer);
    } catch (err) {
      console.error("[/api/source-download] Error:", err);
      res.status(500).json({ error: "소스코드 ZIP 생성 중 오류가 발생했습니다." });
    }
  });

  app.post("/api/ai/recommend", async (req, res) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY가 설정되어 있지 않습니다. Settings > Secrets 패널에서 API 키를 설정해 주세요.",
      });
      return;
    }

    const body = (req.body ?? {}) as RecommendRequestBody;
    const destination = String(body.destination ?? "").trim();
    const daysCount = Math.min(Math.max(Number(body.daysCount) || 3, 1), 10);
    const companions = String(body.companions ?? "친구").trim();
    const pace = String(body.pace ?? "균형 있게").trim();
    const themes = Array.isArray(body.themes) ? body.themes.filter(Boolean).map(String) : [];
    const extraNotes = String(body.extraNotes ?? "").trim();

    if (!destination) {
      res.status(400).json({ error: "여행지를 입력해 주세요." });
      return;
    }

    const themeText = themes.length > 0 ? themes.join(", ") : "로컬 산책, 미식, 문화 체험";
    const itemsPerDayGuidance =
      pace === "여유롭게"
        ? "하루 3~4개의 여유 있는 일정"
        : pace === "알차게"
          ? "하루 5~6개의 알찬 일정"
          : "하루 4~5개의 균형 잡힌 일정";

    const prompt = [
      `당신은 잡지 'Kinfolk'와 'Monocle' 스타일의 안목을 지닌 여행 에디터입니다.`,
      `다음 조건에 맞춰 현실적이고 동선이 매끄러운 한국어 맞춤 여행 일정을 설계해 주세요.`,
      `- 여행지: ${destination}`,
      `- 여행 기간: ${daysCount}일`,
      `- 동행 형태: ${companions}`,
      `- 여행 페이스: ${pace} (${itemsPerDayGuidance})`,
      `- 선호 테마: ${themeText}`,
      extraNotes ? `- 추가 요청사항: ${extraNotes}` : "",
      ``,
      `작성 원칙:`,
      `1. 실제로 존재하는 권역/동네와 대표 장소를 중심으로 이동 동선이 자연스럽게 이어지도록 구성하세요.`,
      `2. 각 일자(day)는 매거진 챕터처럼 시적이고 명료한 소제목(title)과 한 줄 동선 요약(summary)을 가지세요.`,
      `3. 각 일정(item)의 time은 'HH:mm' 24시간 형식(예: '09:30')으로 시간순 정렬하세요.`,
      `4. category는 반드시 다음 중 하나만 사용하세요: 관광, 미식, 카페, 숙소, 이동, 쇼핑, 휴식.`,
      `5. note는 에디토리얼 저널 톤의 감성적이고 실용적인 한두 문장으로, transitTip은 직전 장소에서의 간단한 이동 방법으로 작성하세요.`,
      `6. estimatedCost는 원화(KRW) 기준 1인 예상 비용 숫자(정수, 무료는 0)로 기입하세요.`,
    ]
      .filter(Boolean)
      .join("\n");

    try {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "항상 유효한 JSON 객체만 출력하세요. 모든 텍스트는 자연스럽고 품격 있는 한국어로 작성하며, 과장된 감탄사나 이모지를 쓰지 마세요.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              journalNote: { type: Type.STRING },
              days: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dayNumber: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    summary: { type: Type.STRING },
                    items: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          time: { type: Type.STRING },
                          durationMinutes: { type: Type.INTEGER },
                          title: { type: Type.STRING },
                          category: { type: Type.STRING },
                          area: { type: Type.STRING },
                          note: { type: Type.STRING },
                          transitTip: { type: Type.STRING },
                          estimatedCost: { type: Type.INTEGER },
                        },
                        required: [
                          "time",
                          "durationMinutes",
                          "title",
                          "category",
                          "area",
                          "note",
                          "transitTip",
                          "estimatedCost",
                        ],
                      },
                    },
                  },
                  required: ["dayNumber", "title", "summary", "items"],
                },
              },
            },
            required: ["title", "journalNote", "days"],
          },
        },
      });

      const rawText = (response.text ?? "").trim();
      if (!rawText) {
        res.status(502).json({ error: "AI 응답이 비어 있습니다. 다시 시도해 주세요." });
        return;
      }

      const parsed = JSON.parse(rawText) as {
        title?: string;
        journalNote?: string;
        days?: Array<{
          dayNumber?: number;
          title?: string;
          summary?: string;
          items?: Array<{
            time?: string;
            durationMinutes?: number;
            title?: string;
            category?: string;
            area?: string;
            note?: string;
            transitTip?: string;
            estimatedCost?: number;
          }>;
        }>;
      };

      const normalizedDays = (parsed.days ?? []).map((day, idx) => ({
        dayNumber: Number(day.dayNumber) || idx + 1,
        title: String(day.title ?? `Day ${idx + 1}`),
        summary: String(day.summary ?? ""),
        items: (day.items ?? []).map((item) => ({
          time: String(item.time ?? "10:00"),
          durationMinutes: Math.max(15, Number(item.durationMinutes) || 60),
          title: String(item.title ?? "추천 일정"),
          category: normalizeCategory(item.category),
          area: String(item.area ?? destination),
          note: String(item.note ?? ""),
          transitTip: String(item.transitTip ?? ""),
          estimatedCost: Math.max(0, Math.round(Number(item.estimatedCost) || 0)),
        })),
      }));

      res.json({
        title: String(parsed.title ?? `${destination} 여행 저널`),
        journalNote: String(parsed.journalNote ?? ""),
        days: normalizedDays,
      });
    } catch (err) {
      console.error("[/api/ai/recommend] Error:", err);
      const mapped = extractUpstreamError(err);
      res.status(mapped.status).json({ error: mapped.message });
    }
  });

  app.post("/api/ai/suggest-spot", async (req, res) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY가 설정되어 있지 않습니다. Settings > Secrets 패널에서 API 키를 설정해 주세요.",
      });
      return;
    }

    const body = (req.body ?? {}) as SuggestSpotRequestBody;
    const destination = String(body.destination ?? "").trim();
    const dayNumber = Number(body.dayNumber) || 1;
    const dayTitle = String(body.dayTitle ?? "").trim();
    const existingTitles = Array.isArray(body.existingTitles)
      ? body.existingTitles.map(String).filter(Boolean)
      : [];
    const companions = String(body.companions ?? "친구").trim();
    const requestNote = String(body.requestNote ?? "").trim();

    if (!destination) {
      res.status(400).json({ error: "여행지 정보가 필요합니다." });
      return;
    }

    const prompt = [
      `여행지 '${destination}'의 ${dayNumber}일차(${dayTitle || "일정"})에 추가하거나 대체할 만한 장소 3곳을 추천해 주세요.`,
      `동행 형태: ${companions}`,
      existingTitles.length > 0 ? `이미 포함된 일정(중복 제외): ${existingTitles.join(", ")}` : "",
      requestNote ? `사용자 요청: ${requestNote}` : "오후 티타임, 로컬 식당, 혹은 조용히 걷기 좋은 장소를 균형 있게 제안해 주세요.",
      `category는 반드시 관광, 미식, 카페, 숙소, 이동, 쇼핑, 휴식 중 하나를 사용하세요.`,
    ]
      .filter(Boolean)
      .join("\n");

    try {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "항상 유효한 JSON 객체만 출력하세요. 한국어 에디토리얼 톤을 유지하고 이모지를 사용하지 마세요.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              suggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    time: { type: Type.STRING },
                    durationMinutes: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    category: { type: Type.STRING },
                    area: { type: Type.STRING },
                    note: { type: Type.STRING },
                    transitTip: { type: Type.STRING },
                    estimatedCost: { type: Type.INTEGER },
                  },
                  required: [
                    "time",
                    "durationMinutes",
                    "title",
                    "category",
                    "area",
                    "note",
                    "transitTip",
                    "estimatedCost",
                  ],
                },
              },
            },
            required: ["suggestions"],
          },
        },
      });

      const rawText = (response.text ?? "").trim();
      const parsed = JSON.parse(rawText) as {
        suggestions?: Array<{
          time?: string;
          durationMinutes?: number;
          title?: string;
          category?: string;
          area?: string;
          note?: string;
          transitTip?: string;
          estimatedCost?: number;
        }>;
      };

      const suggestions = (parsed.suggestions ?? []).map((item) => ({
        time: String(item.time ?? "15:00"),
        durationMinutes: Math.max(15, Number(item.durationMinutes) || 60),
        title: String(item.title ?? "추천 장소"),
        category: normalizeCategory(item.category),
        area: String(item.area ?? destination),
        note: String(item.note ?? ""),
        transitTip: String(item.transitTip ?? ""),
        estimatedCost: Math.max(0, Math.round(Number(item.estimatedCost) || 0)),
      }));

      res.json({ suggestions });
    } catch (err) {
      console.error("[/api/ai/suggest-spot] Error:", err);
      const mapped = extractUpstreamError(err);
      res.status(mapped.status).json({ error: mapped.message });
    }
  });

  app.post("/api/ai/rebalance-day", async (req, res) => {
    const ai = getAiClient();
    if (!ai) {
      res.status(503).json({
        error: "GEMINI_API_KEY가 설정되어 있지 않습니다. Settings > Secrets 패널에서 API 키를 설정해 주세요.",
      });
      return;
    }

    const body = (req.body ?? {}) as RebalanceDayRequestBody;
    const destination = String(body.destination ?? "").trim();
    const dayNumber = Number(body.dayNumber) || 1;
    const dayTitle = String(body.dayTitle ?? "").trim();
    const companions = String(body.companions ?? "친구").trim();
    const mode = body.mode ?? "optimize_route";
    const customInstruction = String(body.customInstruction ?? "").trim();
    const items = Array.isArray(body.items) ? body.items : [];

    if (!destination || items.length === 0) {
      res.status(400).json({ error: "리밸런싱할 일차의 여행지 및 기존 일정이 필요합니다." });
      return;
    }

    const modeDirective =
      mode === "rainy_indoor"
        ? "비 오는 날을 대비해 기존 야외 관광/산책 일정을 인근 실내 미술관, 아케이드 시장, 고즈넉한 찻집·카페 등 실내 대안 장소로 자연스럽게 교체하세요. 기존 식사·실내 일정은 가급적 유지하세요."
        : mode === "relaxed_pace"
          ? "체력 부담을 줄이고 여유롭게 머물 수 있도록 지나치게 촘촘한 시간 간격을 넓히고 휴식·카페 타임을 적절히 배치해 재구성하세요."
          : "기존 장소들을 최대한 유지하되 권역(동네) 간 이동 거리가 겹치지 않도록 순서를 재배치하고 시간대·이동 메모(transitTip)를 현실적으로 최적화하세요.";

    const serializedItems = items
      .map(
        (it, i) =>
          `${i + 1}. [${it.time} / ${it.durationMinutes}분] ${it.title} (${it.category}, ${it.area}) - ${it.note}`
      )
      .join("\n");

    const prompt = [
      `여행지: ${destination} (${dayNumber}일차: ${dayTitle || "여정"}, 동행: ${companions})`,
      `리밸런싱 목표: ${modeDirective}`,
      customInstruction ? `추가 조건: ${customInstruction}` : "",
      ``,
      `현재 일정 목록:`,
      serializedItems,
      ``,
      `위 일정을 목표에 맞게 재구성하여 dayTitle, summary, reason(변경 요약 1~2문장), 그리고 시간순 정렬된 items 배열을 반환하세요.`,
      `category는 반드시 관광, 미식, 카페, 숙소, 이동, 쇼핑, 휴식 중 하나를 사용하세요.`,
    ]
      .filter(Boolean)
      .join("\n");

    try {
      const response = await ai.models.generateContent({
        model: MODEL_NAME,
        contents: prompt,
        config: {
          systemInstruction:
            "항상 유효한 JSON 객체만 출력하세요. 에디토리얼 매거진 톤의 정갈한 한국어로 작성하세요.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              reason: { type: Type.STRING },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    time: { type: Type.STRING },
                    durationMinutes: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    category: { type: Type.STRING },
                    area: { type: Type.STRING },
                    note: { type: Type.STRING },
                    transitTip: { type: Type.STRING },
                    estimatedCost: { type: Type.INTEGER },
                  },
                  required: [
                    "time",
                    "durationMinutes",
                    "title",
                    "category",
                    "area",
                    "note",
                    "transitTip",
                    "estimatedCost",
                  ],
                },
              },
            },
            required: ["title", "summary", "reason", "items"],
          },
        },
      });

      const rawText = (response.text ?? "").trim();
      const parsed = JSON.parse(rawText) as {
        title?: string;
        summary?: string;
        reason?: string;
        items?: Array<{
          time?: string;
          durationMinutes?: number;
          title?: string;
          category?: string;
          area?: string;
          note?: string;
          transitTip?: string;
          estimatedCost?: number;
        }>;
      };

      res.json({
        title: String(parsed.title ?? dayTitle),
        summary: String(parsed.summary ?? ""),
        reason: String(parsed.reason ?? "일정 동선과 시간표를 재구성했습니다."),
        items: (parsed.items ?? []).map((item) => ({
          time: String(item.time ?? "10:00"),
          durationMinutes: Math.max(15, Number(item.durationMinutes) || 60),
          title: String(item.title ?? "추천 일정"),
          category: normalizeCategory(item.category),
          area: String(item.area ?? destination),
          note: String(item.note ?? ""),
          transitTip: String(item.transitTip ?? ""),
          estimatedCost: Math.max(0, Math.round(Number(item.estimatedCost) || 0)),
        })),
      });
    } catch (err) {
      console.error("[/api/ai/rebalance-day] Error:", err);
      const mapped = extractUpstreamError(err);
      res.status(mapped.status).json({ error: mapped.message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, "dist");
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get("/{*path}", (_req, res) => {
        res.sendFile(path.join(distDir, "index.html"));
      });
    }
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Travel Journal server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
